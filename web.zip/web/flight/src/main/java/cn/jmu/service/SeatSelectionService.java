package cn.jmu.service;

import cn.jmu.bean.SeatSelection;
import cn.jmu.bean.SeatSelectionExample;
import cn.jmu.dao.SeatSelectionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatSelectionService {
    @Autowired
    SeatSelectionMapper seatSelectionMapper;
    public boolean insertSeatSelection(SeatSelection seatSelection){
        return seatSelectionMapper.insertSelective(seatSelection);
    }
    public List<SeatSelection> findSeatSelection(String executiveflightid){
        SeatSelectionExample seatSelectionExample=new SeatSelectionExample();
        SeatSelectionExample.Criteria criteria=seatSelectionExample.createCriteria();
        criteria.andExecutiveflightidEqualTo(executiveflightid);
        seatSelectionExample.setOrderByClause("seatid asc");
        return seatSelectionMapper.selectByExample(seatSelectionExample);
    }
}
