USE [master]
GO
/****** Object:  Database [flight]    Script Date: 2020/6/27 19:54:17 ******/
CREATE DATABASE [flight]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'FLIGHT_Data', FILENAME = N'D:\flight\flight.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'FLIGHT_Log', FILENAME = N'D:\flight\flight.ldf' , SIZE = 2560KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [flight].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [flight] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [flight] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [flight] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [flight] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [flight] SET ARITHABORT OFF 
GO
ALTER DATABASE [flight] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [flight] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [flight] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [flight] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [flight] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [flight] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [flight] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [flight] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [flight] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [flight] SET  ENABLE_BROKER 
GO
ALTER DATABASE [flight] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [flight] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [flight] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [flight] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [flight] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [flight] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [flight] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [flight] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [flight] SET  MULTI_USER 
GO
ALTER DATABASE [flight] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [flight] SET DB_CHAINING OFF 
GO
ALTER DATABASE [flight] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [flight] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [flight] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [flight] SET QUERY_STORE = OFF
GO
USE [flight]
GO
/****** Object:  User [ycb]    Script Date: 2020/6/27 19:54:17 ******/
CREATE USER [ycb] FOR LOGIN [ycb] WITH DEFAULT_SCHEMA=[ycb]
GO
/****** Object:  User [admin]    Script Date: 2020/6/27 19:54:17 ******/
CREATE USER [admin] FOR LOGIN [admin] WITH DEFAULT_SCHEMA=[admin]
GO
/****** Object:  DatabaseRole [users]    Script Date: 2020/6/27 19:54:18 ******/
CREATE ROLE [users]
GO
/****** Object:  DatabaseRole [adm]    Script Date: 2020/6/27 19:54:18 ******/
CREATE ROLE [adm]
GO
ALTER ROLE [users] ADD MEMBER [ycb]
GO
ALTER ROLE [adm] ADD MEMBER [admin]
GO
/****** Object:  Schema [admin]    Script Date: 2020/6/27 19:54:18 ******/
CREATE SCHEMA [admin]
GO
/****** Object:  Schema [ycb]    Script Date: 2020/6/27 19:54:18 ******/
CREATE SCHEMA [ycb]
GO
/****** Object:  Table [dbo].[airport]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[airport](
	[airportId] [int] NOT NULL,
	[cityId] [int] NOT NULL,
	[airportName] [varchar](25) NULL,
	[address] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[cabin]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[cabin](
	[cabinId] [int] NOT NULL,
	[cabinLevel] [char](6) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[city]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[city](
	[cityId] [int] NOT NULL,
	[provinceId] [int] NOT NULL,
	[cityName] [varchar](20) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[executiveFlight]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[executiveFlight](
	[executiveFlightId] [char](10) NOT NULL,
	[flightId] [char](10) NOT NULL,
	[executiveDate] [datetime] NULL,
	[executivePrice] [numeric](8, 2) NULL,
	[flightStatus] [varchar](10) NULL,
	[ETD] [datetime] NULL,
	[ATD] [datetime] NULL,
	[ETA] [datetime] NULL,
	[ATA] [datetime] NULL,
	[boardingGate] [varchar](10) NULL,
	[boardingTime] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[flight]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[flight](
	[flightId] [char](10) NOT NULL,
	[modelId] [char](10) NOT NULL,
	[terminalId] [int] NOT NULL,
	[ter_terminalId] [int] NOT NULL,
	[plannedDepartureTtime] [datetime] NULL,
	[plannedArrivalTime] [datetime] NULL,
	[pricing] [numeric](8, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[terminal]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[terminal](
	[terminalId] [int] NOT NULL,
	[airportId] [int] NOT NULL,
	[terminalName] [varchar](15) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ticketType]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ticketType](
	[cabinId] [int] NOT NULL,
	[executiveFlightId] [char](10) NOT NULL,
	[sellingPrice] [numeric](8, 2) NULL,
	[effectiveStartTime] [datetime] NULL,
	[effectiveEndTime] [datetime] NULL,
	[discount] [numeric](4, 2) NULL,
	[remainingTickets] [int] NULL,
	[luggageAllowance] [int] NULL,
	[luggageNumber] [int] NULL,
	[mealStatus] [char](2) NULL,
	[rules] [varchar](500) NULL,
 CONSTRAINT [PK_TICKETTYPE] PRIMARY KEY CLUSTERED 
(
	[cabinId] ASC,
	[executiveFlightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[findticket]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[findticket](flightId,executiveFlightId,departurecity,arrivalcity,departuretime,arrivaltime,cabinId,cabinLevel,executivePrice,sellingPrice,discount,remainingTickets,luggageAllowance,luggageNumber,mealStatus,rules,departureairportName,arrivalairportName,departureterminalName,arrivalterminalName,integral)                                          
as
select flight.flightId,executiveFlight.executiveFlightId,c1.cityName,c2.cityName,executiveFlight.ETD,executiveFlight.ETA,cabin.cabinId,cabin.cabinLevel,executiveFlight.executivePrice,
ticketType.sellingPrice,ticketType.discount,ticketType.remainingTickets,ticketType.luggageAllowance,ticketType.luggageNumber,ticketType.mealStatus,ticketType.rules,
a1.airportName,a2.airportName,t1.terminalName,t2.terminalName,ticketType.sellingPrice/10
from flight,city c1,city c2,airport a1,airport a2,terminal t1,terminal t2,executiveFlight,ticketType,cabin
where a1.cityId=c1.cityId and a2.cityId=c2.cityId and t1.airportId=a1.airportId and t2.airportId = a2.airportId
and flight.terminalId=t1.terminalId and flight.ter_terminalId=t2.terminalId and executiveFlight.flightId=flight.flightId and ticketType.cabinId=cabin.cabinId 
and ticketType.executiveFlightId=executiveFlight.executiveFlightId
GO
/****** Object:  View [dbo].[flightInformation]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[flightInformation](flightId,executiveFlightId,departurecity,arrivalcity,departureAirport,arrivalAirport,plannedDepartureTtime,plannedArrivalTime,ETD,ETA,ATD,ATA,flightStatus)                                          
as
select flight.flightId,executiveFlight.executiveFlightId,c1.cityName,c2.cityName,a1.airportName,a2.airportName,flight.plannedDepartureTtime,flight.plannedArrivalTime,
executiveFlight.ETD,executiveFlight.ETA,executiveFlight.ATD,executiveFlight.ATA,executiveFlight.flightStatus
from flight,city c1,city c2,airport a1,airport a2,terminal t1,terminal t2,executiveFlight
where a1.cityId=c1.cityId and a2.cityId=c2.cityId and t1.airportId=a1.airportId and t2.airportId = a2.airportId
and flight.terminalId=t1.terminalId and flight.ter_terminalId=t2.terminalId and executiveFlight.flightId=flight.flightId
GO
/****** Object:  Table [dbo].[administrator]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[administrator](
	[adminId] [int] IDENTITY(1,1) NOT NULL,
	[loginId] [varchar](25) NULL,
	[password] [varchar](20) NULL,
	[authority] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[airportManager]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[airportManager](
	[managerId] [int] NOT NULL,
	[authority] [varchar](100) NULL,
	[loginId] [varchar](25) NULL,
	[password] [varchar](20) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[binding]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[binding](
	[userId] [int] NOT NULL,
	[passengerId] [char](18) NOT NULL,
 CONSTRAINT [PK_BINDING] PRIMARY KEY CLUSTERED 
(
	[userId] ASC,
	[passengerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[luggage]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[luggage](
	[luggageId] [int] IDENTITY(1,1) NOT NULL,
	[ticketId] [int] NOT NULL,
	[luggageWeight] [numeric](5, 2) NULL,
	[length] [numeric](5, 2) NULL,
	[width] [numeric](5, 2) NULL,
	[height] [numeric](5, 2) NULL,
	[fine] [numeric](8, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[model]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[model](
	[modelId] [char](10) NOT NULL,
	[modelName] [varchar](20) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[orders]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[orders](
	[orderId] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[userId] [int] NOT NULL,
	[offsetIntegral] [int] NULL,
	[totalCost] [numeric](8, 2) NULL,
	[orderStatusx] [varchar](10) NULL,
	[telephone] [char](11) NULL,
	[createTime] [datetime] NOT NULL,
	[paidTime] [datetime] NULL,
	[linkman] [varchar](10) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[passenger]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[passenger](
	[passengerId] [char](18) NOT NULL,
	[passengerName] [varchar](10) NOT NULL,
	[passengerSex] [char](2) NULL,
	[passengerTel] [char](11) NOT NULL,
	[creditStatus] [varchar](10) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[province]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[province](
	[provinceId] [int] NOT NULL,
	[provinceName] [varchar](10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[seatingChart]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[seatingChart](
	[seatId] [int] IDENTITY(1,1) NOT NULL,
	[modelId] [char](10) NOT NULL,
	[cabinId] [int] NOT NULL,
	[position] [varchar](10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[seatSelection]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[seatSelection](
	[seatId] [int] NOT NULL,
	[executiveFlightId] [char](10) NOT NULL,
	[ticketId] [int] NULL,
	[seatStatus] [varchar](10) NULL,
 CONSTRAINT [PK_SEATSELECTION] PRIMARY KEY CLUSTERED 
(
	[seatId] ASC,
	[executiveFlightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ticket]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ticket](
	[ticketId] [int] IDENTITY(1,1) NOT NULL,
	[orderId] [int] NOT NULL,
	[passengerId] [char](18) NOT NULL,
	[cabinId] [int] NOT NULL,
	[tic_executiveFlightId] [char](10) NOT NULL,
	[airportConstructionCost] [numeric](8, 2) NULL,
	[insuranceCost] [numeric](8, 2) NULL,
	[totalCost] [numeric](8, 2) NULL,
	[remarks] [varchar](200) NULL,
	[checkStatus] [varchar](10) NULL,
	[boardingId] [varchar](10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[users]    Script Date: 2020/6/27 19:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[users](
	[userId] [int] IDENTITY(1,1) NOT NULL,
	[loginId] [varchar](25) NOT NULL,
	[password] [varchar](20) NULL,
	[userName] [varchar](10) NULL,
	[userSex] [char](2) NULL,
	[userAge] [int] NULL,
	[integral] [int] NULL
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[administrator] ON 
GO
INSERT [dbo].[administrator] ([adminId], [loginId], [password], [authority]) VALUES (3902, N'Admin3902', N'200217', N'增删改查航班')
GO
SET IDENTITY_INSERT [dbo].[administrator] OFF
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (1, 350200, N'高崎国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (2, 430100, N'黄花国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (3, 310000, N'虹桥国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (4, 440300, N'宝安国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (5, 110000, N'大兴国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (6, 440100, N'白云国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (7, 510100, N'双流国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (8, 330100, N'萧山国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (9, 500000, N'江北国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (10, 530100, N'长水国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (11, 610100, N'咸阳国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (12, 420100, N'天河国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (13, 320100, N'禄口国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (14, 370200, N'流亭国际机场', N'')
GO
INSERT [dbo].[airport] ([airportId], [cityId], [airportName], [address]) VALUES (15, 460200, N'凤凰国际机场', N'')
GO
INSERT [dbo].[binding] ([userId], [passengerId]) VALUES (2, N'12045320010523957X')
GO
INSERT [dbo].[binding] ([userId], [passengerId]) VALUES (2, N'365412199604254789')
GO
INSERT [dbo].[binding] ([userId], [passengerId]) VALUES (2, N'42856119840525321X')
GO
INSERT [dbo].[binding] ([userId], [passengerId]) VALUES (2, N'630279200006165389')
GO
INSERT [dbo].[binding] ([userId], [passengerId]) VALUES (2, N'907824197911054921')
GO
INSERT [dbo].[cabin] ([cabinId], [cabinLevel]) VALUES (1, N'头等舱')
GO
INSERT [dbo].[cabin] ([cabinId], [cabinLevel]) VALUES (2, N'商务舱')
GO
INSERT [dbo].[cabin] ([cabinId], [cabinLevel]) VALUES (3, N'经济舱')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350200, 35, N'厦门市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430100, 43, N'长沙市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130100, 13, N'石家庄市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130200, 13, N'唐山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130300, 13, N'秦皇岛市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130400, 13, N'邯郸市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130500, 13, N'邢台市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130600, 13, N'保定市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130700, 13, N'张家口市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130800, 13, N'承德市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (130900, 13, N'沧州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (131000, 13, N'廊坊市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (131100, 13, N'衡水市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (110000, 11, N'北京市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (120000, 12, N'天津市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140100, 14, N'太原市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140200, 14, N'大同市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140300, 14, N'阳泉市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140400, 14, N'长治市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140500, 14, N'晋城市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140600, 14, N'朔州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140700, 14, N'晋中市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140800, 14, N'运城市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (140900, 14, N'忻州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (141000, 14, N'临汾市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (141100, 14, N'吕梁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150100, 15, N'呼和浩特市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150200, 15, N'包头市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150300, 15, N'乌海市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150400, 15, N'赤峰市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150500, 15, N'通辽市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150600, 15, N'鄂尔多斯市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150700, 15, N'呼伦贝尔市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150800, 15, N'巴彦淖尔市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (150900, 15, N'乌兰察布市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152100, 15, N'呼伦贝尔盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152200, 15, N'兴安盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152300, 15, N'哲里木盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152400, 15, N'昭乌达盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152500, 15, N'锡林郭勒盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152600, 15, N'乌兰察布盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152700, 15, N'伊克昭盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152800, 15, N'巴彦淖尔盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (152900, 15, N'阿拉善盟')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210100, 21, N'沈阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210200, 21, N'大连市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210300, 21, N'鞍山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210400, 21, N'抚顺市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210500, 21, N'本溪市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210600, 21, N'丹东市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210700, 21, N'锦州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210800, 21, N'营口市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (210900, 21, N'阜新市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (211000, 21, N'辽阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (211100, 21, N'盘锦市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (211200, 21, N'铁岭市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (211300, 21, N'朝阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (211400, 21, N'葫芦岛市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220100, 22, N'长春市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220200, 22, N'吉林市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220300, 22, N'四平市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220400, 22, N'辽源市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220500, 22, N'通化市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220600, 22, N'白山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220700, 22, N'松原市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (220800, 22, N'白城市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230100, 23, N'哈尔滨市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230200, 23, N'齐齐哈尔市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230300, 23, N'鸡西市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230400, 23, N'鹤岗市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230500, 23, N'双鸭山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230600, 23, N'大庆市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230700, 23, N'伊春市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230800, 23, N'佳木斯市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (230900, 23, N'七台河市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (231000, 23, N'牡丹江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (231100, 23, N'黑河市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (231200, 23, N'绥化市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (310000, 31, N'上海市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320100, 32, N'南京市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320200, 32, N'无锡市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320300, 32, N'徐州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320400, 32, N'常州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320500, 32, N'苏州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320600, 32, N'南通市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320700, 32, N'连云港市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320800, 32, N'淮安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (320900, 32, N'盐城市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (321000, 32, N'扬州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (321100, 32, N'镇江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (321200, 32, N'泰州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (321300, 32, N'宿迁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330100, 33, N'杭州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330200, 33, N'宁波市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330300, 33, N'温州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330400, 33, N'嘉兴市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330500, 33, N'湖州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330600, 33, N'绍兴市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330700, 33, N'金华市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330800, 33, N'衢州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (330900, 33, N'舟山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (331000, 33, N'台州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (331100, 33, N'丽水市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340100, 34, N'合肥市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340200, 34, N'芜湖市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340300, 34, N'蚌埠市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340400, 34, N'淮南市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340500, 34, N'马鞍山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340600, 34, N'淮北市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340700, 34, N'铜陵市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340800, 34, N'安庆市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (340900, 34, N'黄山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341000, 34, N'黄山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341100, 34, N'滁州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341200, 34, N'阜阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341300, 34, N'宿州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341400, 34, N'巢湖市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341500, 34, N'六安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341600, 34, N'亳州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341700, 34, N'池州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (341800, 34, N'宣城市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350100, 35, N'福州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350300, 35, N'莆田市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350400, 35, N'三明市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350500, 35, N'泉州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350600, 35, N'漳州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350700, 35, N'南平市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350800, 35, N'龙岩市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (350900, 35, N'宁德市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360100, 36, N'南昌市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360200, 36, N'景德镇市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360300, 36, N'萍乡市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360400, 36, N'九江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360500, 36, N'新余市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360600, 36, N'鹰潭市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360700, 36, N'赣州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360800, 36, N'吉安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (360900, 36, N'宜春市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (361000, 36, N'抚州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (361100, 36, N'上饶市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370100, 37, N'济南市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370200, 37, N'青岛市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370300, 37, N'淄博市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370400, 37, N'枣庄市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370500, 37, N'东营市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370600, 37, N'烟台市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370700, 37, N'潍坊市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370800, 37, N'济宁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (370900, 37, N'泰安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371000, 37, N'威海市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371100, 37, N'日照市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371200, 37, N'莱芜市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371300, 37, N'临沂市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371400, 37, N'德州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371500, 37, N'聊城市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371600, 37, N'滨州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (371700, 37, N'菏泽市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410100, 41, N'郑州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410200, 41, N'开封市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410300, 41, N'洛阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410400, 41, N'平顶山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410500, 41, N'安阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410600, 41, N'鹤壁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410700, 41, N'新乡市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410800, 41, N'焦作市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (410900, 41, N'濮阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411000, 41, N'许昌市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411100, 41, N'漯河市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411200, 41, N'三门峡市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411300, 41, N'南阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411400, 41, N'商丘市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411500, 41, N'信阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411600, 41, N'周口市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (411700, 41, N'驻马店市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420100, 42, N'武汉市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420200, 42, N'黄石市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420300, 42, N'十堰市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420400, 42, N'沙市市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420500, 42, N'宜昌市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420600, 42, N'襄阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420700, 42, N'鄂州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420800, 42, N'荆门市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (420900, 42, N'孝感市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (421000, 42, N'荆州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (421100, 42, N'黄冈市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (421200, 42, N'咸宁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (421300, 42, N'随州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (422800, 42, N'恩施土家族苗族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430200, 43, N'株洲市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430300, 43, N'湘潭市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430400, 43, N'衡阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430500, 43, N'邵阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430600, 43, N'岳阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430700, 43, N'常德市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430800, 43, N'张家界市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (430900, 43, N'益阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (431000, 43, N'郴州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (431100, 43, N'永州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (431200, 43, N'怀化市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (431300, 43, N'娄底市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (432300, 43, N'益阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (433100, 43, N'湘西土家族苗族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440100, 44, N'广州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440200, 44, N'韶关市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440300, 44, N'深圳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440400, 44, N'珠海市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440500, 44, N'汕头市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440600, 44, N'佛山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440700, 44, N'江门市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440800, 44, N'湛江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (440900, 44, N'茂名市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441000, 44, N'海口市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441200, 44, N'肇庆市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441300, 44, N'惠州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441400, 44, N'梅州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441500, 44, N'汕尾市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441600, 44, N'河源市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441700, 44, N'阳江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441800, 44, N'清远市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (441900, 44, N'东莞市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (442000, 44, N'中山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (442100, 44, N'海南行政区')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (442200, 44, N'三亚市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (445100, 44, N'潮州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (445200, 44, N'揭阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (445300, 44, N'云浮市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450100, 45, N'南宁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450200, 45, N'柳州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450300, 45, N'桂林市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450400, 45, N'梧州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450500, 45, N'北海市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450600, 45, N'防城港市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450700, 45, N'钦州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450800, 45, N'贵港市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (450900, 45, N'玉林市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (451000, 45, N'百色市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (451100, 45, N'贺州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (451200, 45, N'河池市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (451300, 45, N'来宾市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (451400, 45, N'崇左市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (460100, 46, N'海口市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (460200, 46, N'三亚市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (460300, 46, N'三沙市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (500000, 50, N'重庆市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510100, 51, N'成都市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510300, 51, N'自贡市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510400, 51, N'攀枝花市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510500, 51, N'泸州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510600, 51, N'德阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510700, 51, N'绵阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510800, 51, N'广元市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (510900, 51, N'遂宁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511000, 51, N'内江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511100, 51, N'乐山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511300, 51, N'南充市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511400, 51, N'眉山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511500, 51, N'宜宾市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511600, 51, N'广安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511700, 51, N'达州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511800, 51, N'雅安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (511900, 51, N'巴中市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (512000, 51, N'资阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (513200, 51, N'阿坝藏族羌族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (513300, 51, N'甘孜藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (513400, 51, N'凉山彝族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (520100, 52, N'贵阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (520200, 52, N'六盘水市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (520300, 52, N'遵义市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (520400, 52, N'安顺市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (520500, 52, N'毕节市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (520600, 52, N'铜仁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (522600, 52, N'黔东南苗族侗族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (522700, 52, N'黔南布依族苗族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530100, 53, N'昆明市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530200, 53, N'东川市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530300, 53, N'曲靖市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530400, 53, N'玉溪市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530500, 53, N'保山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530600, 53, N'昭通市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530700, 53, N'丽江市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530800, 53, N'普洱市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (530900, 53, N'临沧市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (532300, 53, N'楚雄彝族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (532500, 53, N'红河哈尼族彝族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (532600, 53, N'文山壮族苗族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (532800, 53, N'西双版纳傣族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (532900, 53, N'大理白族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (533100, 53, N'德宏傣族景颇族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (533300, 53, N'怒江傈僳族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (533400, 53, N'迪庆藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (540100, 54, N'拉萨市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (540200, 54, N'日喀则市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610100, 61, N'西安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610200, 61, N'铜川市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610300, 61, N'宝鸡市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610400, 61, N'咸阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610500, 61, N'渭南市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610600, 61, N'延安市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610700, 61, N'汉中市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610800, 61, N'榆林市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (610900, 61, N'安康市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (611000, 61, N'商洛市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (612300, 61, N'汉中市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620100, 62, N'兰州市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620200, 62, N'嘉峪关市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620300, 62, N'金昌市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620400, 62, N'白银市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620500, 62, N'天水市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620600, 62, N'武威市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620700, 62, N'张掖市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620800, 62, N'平凉市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (620900, 62, N'酒泉市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (621000, 62, N'庆阳市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (621100, 62, N'定西市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (621200, 62, N'陇南市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (622900, 62, N'临夏回族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (623000, 62, N'甘南藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (630100, 63, N'西宁市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (630200, 63, N'海东市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (632200, 63, N'海北藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (632300, 63, N'黄南藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (632500, 63, N'海南藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (632600, 63, N'果洛藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (632700, 63, N'玉树藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (632800, 63, N'海西蒙古族藏族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (640100, 64, N'银川市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (640200, 64, N'石嘴山市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (640300, 64, N'吴忠市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (640400, 64, N'固原市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (640500, 64, N'中卫市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (650100, 65, N'乌鲁木齐市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (650200, 65, N'克拉玛依市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (650300, 65, N'石河子市')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (652300, 65, N'昌吉回族自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (652400, 65, N'伊犁哈萨克自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (652700, 65, N'博尔塔拉蒙古自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (652800, 65, N'巴音郭楞蒙古自治州')
GO
INSERT [dbo].[city] ([cityId], [provinceId], [cityName]) VALUES (654000, 65, N'伊犁哈萨克自治州')
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000000', N'MF00000001', CAST(N'2020-06-30T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T02:50:25.000' AS DateTime), CAST(N'2020-06-30T02:50:25.000' AS DateTime), CAST(N'2020-06-30T03:50:25.000' AS DateTime), CAST(N'2020-06-30T04:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000001', N'MF00000001', CAST(N'2020-07-01T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T02:50:25.000' AS DateTime), CAST(N'2020-07-01T02:50:25.000' AS DateTime), CAST(N'2020-07-01T03:50:25.000' AS DateTime), CAST(N'2020-07-01T04:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000002', N'MF00000001', CAST(N'2020-07-02T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T02:50:25.000' AS DateTime), CAST(N'2020-07-02T02:50:25.000' AS DateTime), CAST(N'2020-07-02T03:50:25.000' AS DateTime), CAST(N'2020-07-02T04:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000003', N'MF00000001', CAST(N'2020-07-03T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T02:50:25.000' AS DateTime), CAST(N'2020-07-03T02:50:25.000' AS DateTime), CAST(N'2020-07-03T03:50:25.000' AS DateTime), CAST(N'2020-07-03T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000004', N'MF00000001', CAST(N'2020-07-04T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T02:50:25.000' AS DateTime), CAST(N'2020-07-04T02:50:25.000' AS DateTime), CAST(N'2020-07-04T03:50:25.000' AS DateTime), CAST(N'2020-07-04T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000005', N'MF00000001', CAST(N'2020-07-05T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T02:50:25.000' AS DateTime), CAST(N'2020-07-05T02:50:25.000' AS DateTime), CAST(N'2020-07-05T03:50:25.000' AS DateTime), CAST(N'2020-07-05T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000006', N'MF00000001', CAST(N'2020-07-06T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T02:50:25.000' AS DateTime), CAST(N'2020-07-06T02:50:25.000' AS DateTime), CAST(N'2020-07-06T03:50:25.000' AS DateTime), CAST(N'2020-07-06T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000007', N'MF00000001', CAST(N'2020-07-07T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T02:50:25.000' AS DateTime), CAST(N'2020-07-07T02:50:25.000' AS DateTime), CAST(N'2020-07-07T03:50:25.000' AS DateTime), CAST(N'2020-07-07T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000008', N'MF00000001', CAST(N'2020-07-08T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T02:50:25.000' AS DateTime), CAST(N'2020-07-08T02:50:25.000' AS DateTime), CAST(N'2020-07-08T03:50:25.000' AS DateTime), CAST(N'2020-07-08T04:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000009', N'MF00000001', CAST(N'2020-07-09T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T02:50:25.000' AS DateTime), CAST(N'2020-07-09T02:50:25.000' AS DateTime), CAST(N'2020-07-09T03:50:25.000' AS DateTime), CAST(N'2020-07-09T04:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000010', N'MF00000001', CAST(N'2020-07-10T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T02:50:25.000' AS DateTime), CAST(N'2020-07-10T02:50:25.000' AS DateTime), CAST(N'2020-07-10T03:50:25.000' AS DateTime), CAST(N'2020-07-10T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000011', N'MF00000001', CAST(N'2020-07-11T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T02:50:25.000' AS DateTime), CAST(N'2020-07-11T02:50:25.000' AS DateTime), CAST(N'2020-07-11T03:50:25.000' AS DateTime), CAST(N'2020-07-11T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000012', N'MF00000001', CAST(N'2020-07-12T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T02:50:25.000' AS DateTime), CAST(N'2020-07-12T02:50:25.000' AS DateTime), CAST(N'2020-07-12T03:50:25.000' AS DateTime), CAST(N'2020-07-12T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000013', N'MF00000001', CAST(N'2020-07-13T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T02:50:25.000' AS DateTime), CAST(N'2020-07-13T02:50:25.000' AS DateTime), CAST(N'2020-07-13T03:50:25.000' AS DateTime), CAST(N'2020-07-13T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000014', N'MF00000001', CAST(N'2020-07-14T02:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T02:50:25.000' AS DateTime), CAST(N'2020-07-14T02:50:25.000' AS DateTime), CAST(N'2020-07-14T03:50:25.000' AS DateTime), CAST(N'2020-07-14T03:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000015', N'MF00000002', CAST(N'2020-06-30T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T17:50:25.000' AS DateTime), CAST(N'2020-06-30T17:50:25.000' AS DateTime), CAST(N'2020-06-30T18:50:25.000' AS DateTime), CAST(N'2020-06-30T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000016', N'MF00000002', CAST(N'2020-07-01T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T17:50:25.000' AS DateTime), CAST(N'2020-07-01T17:50:25.000' AS DateTime), CAST(N'2020-07-01T18:50:25.000' AS DateTime), CAST(N'2020-07-01T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000017', N'MF00000002', CAST(N'2020-07-02T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T17:50:25.000' AS DateTime), CAST(N'2020-07-02T17:50:25.000' AS DateTime), CAST(N'2020-07-02T18:50:25.000' AS DateTime), CAST(N'2020-07-02T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000018', N'MF00000002', CAST(N'2020-07-03T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T17:50:25.000' AS DateTime), CAST(N'2020-07-03T17:50:25.000' AS DateTime), CAST(N'2020-07-03T18:50:25.000' AS DateTime), CAST(N'2020-07-03T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000019', N'MF00000002', CAST(N'2020-07-04T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T17:50:25.000' AS DateTime), CAST(N'2020-07-04T17:50:25.000' AS DateTime), CAST(N'2020-07-04T18:50:25.000' AS DateTime), CAST(N'2020-07-04T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000020', N'MF00000002', CAST(N'2020-07-05T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T17:50:25.000' AS DateTime), CAST(N'2020-07-05T17:50:25.000' AS DateTime), CAST(N'2020-07-05T18:50:25.000' AS DateTime), CAST(N'2020-07-05T19:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000021', N'MF00000002', CAST(N'2020-07-06T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T17:50:25.000' AS DateTime), CAST(N'2020-07-06T17:50:25.000' AS DateTime), CAST(N'2020-07-06T18:50:25.000' AS DateTime), CAST(N'2020-07-06T19:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000022', N'MF00000002', CAST(N'2020-07-07T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T17:50:25.000' AS DateTime), CAST(N'2020-07-07T17:50:25.000' AS DateTime), CAST(N'2020-07-07T18:50:25.000' AS DateTime), CAST(N'2020-07-07T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000023', N'MF00000002', CAST(N'2020-07-08T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T17:50:25.000' AS DateTime), CAST(N'2020-07-08T17:50:25.000' AS DateTime), CAST(N'2020-07-08T18:50:25.000' AS DateTime), CAST(N'2020-07-08T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000024', N'MF00000002', CAST(N'2020-07-09T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T17:50:25.000' AS DateTime), CAST(N'2020-07-09T17:50:25.000' AS DateTime), CAST(N'2020-07-09T18:50:25.000' AS DateTime), CAST(N'2020-07-09T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000025', N'MF00000002', CAST(N'2020-07-10T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T17:50:25.000' AS DateTime), CAST(N'2020-07-10T17:50:25.000' AS DateTime), CAST(N'2020-07-10T18:50:25.000' AS DateTime), CAST(N'2020-07-10T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000026', N'MF00000002', CAST(N'2020-07-11T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T17:50:25.000' AS DateTime), CAST(N'2020-07-11T17:50:25.000' AS DateTime), CAST(N'2020-07-11T18:50:25.000' AS DateTime), CAST(N'2020-07-11T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000027', N'MF00000002', CAST(N'2020-07-12T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T17:50:25.000' AS DateTime), CAST(N'2020-07-12T17:50:25.000' AS DateTime), CAST(N'2020-07-12T18:50:25.000' AS DateTime), CAST(N'2020-07-12T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000028', N'MF00000002', CAST(N'2020-07-13T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T17:50:25.000' AS DateTime), CAST(N'2020-07-13T17:50:25.000' AS DateTime), CAST(N'2020-07-13T18:50:25.000' AS DateTime), CAST(N'2020-07-13T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000029', N'MF00000002', CAST(N'2020-07-14T17:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T17:50:25.000' AS DateTime), CAST(N'2020-07-14T17:50:25.000' AS DateTime), CAST(N'2020-07-14T18:50:25.000' AS DateTime), CAST(N'2020-07-14T18:50:25.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000030', N'MF00000003', CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T02:50:26.000' AS DateTime), CAST(N'2020-06-30T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000031', N'MF00000003', CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T02:50:26.000' AS DateTime), CAST(N'2020-07-01T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000032', N'MF00000003', CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T02:50:26.000' AS DateTime), CAST(N'2020-07-02T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000033', N'MF00000003', CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T02:50:26.000' AS DateTime), CAST(N'2020-07-03T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000034', N'MF00000003', CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T02:50:26.000' AS DateTime), CAST(N'2020-07-04T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000035', N'MF00000003', CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T02:50:26.000' AS DateTime), CAST(N'2020-07-05T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000036', N'MF00000003', CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T02:50:26.000' AS DateTime), CAST(N'2020-07-06T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000037', N'MF00000003', CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T02:50:26.000' AS DateTime), CAST(N'2020-07-07T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000038', N'MF00000003', CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T02:50:26.000' AS DateTime), CAST(N'2020-07-08T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000039', N'MF00000003', CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T02:50:26.000' AS DateTime), CAST(N'2020-07-09T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000040', N'MF00000003', CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T02:50:26.000' AS DateTime), CAST(N'2020-07-10T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000041', N'MF00000003', CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T02:50:26.000' AS DateTime), CAST(N'2020-07-11T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000042', N'MF00000003', CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T02:50:26.000' AS DateTime), CAST(N'2020-07-12T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000043', N'MF00000003', CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T02:50:26.000' AS DateTime), CAST(N'2020-07-13T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000044', N'MF00000003', CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T02:50:26.000' AS DateTime), CAST(N'2020-07-14T02:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000045', N'MF00000004', CAST(N'2020-06-30T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T12:50:26.000' AS DateTime), CAST(N'2020-06-30T12:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000046', N'MF00000004', CAST(N'2020-07-01T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T12:50:26.000' AS DateTime), CAST(N'2020-07-01T12:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000047', N'MF00000004', CAST(N'2020-07-02T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T12:50:26.000' AS DateTime), CAST(N'2020-07-02T12:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000048', N'MF00000004', CAST(N'2020-07-03T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T12:50:26.000' AS DateTime), CAST(N'2020-07-03T12:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000049', N'MF00000004', CAST(N'2020-07-04T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T12:50:26.000' AS DateTime), CAST(N'2020-07-04T12:50:26.000' AS DateTime), CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(N'2020-07-04T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000050', N'MF00000004', CAST(N'2020-07-05T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T12:50:26.000' AS DateTime), CAST(N'2020-07-05T12:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000051', N'MF00000004', CAST(N'2020-07-06T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T12:50:26.000' AS DateTime), CAST(N'2020-07-06T12:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000052', N'MF00000004', CAST(N'2020-07-07T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T12:50:26.000' AS DateTime), CAST(N'2020-07-07T12:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000053', N'MF00000004', CAST(N'2020-07-08T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T12:50:26.000' AS DateTime), CAST(N'2020-07-08T12:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000054', N'MF00000004', CAST(N'2020-07-09T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T12:50:26.000' AS DateTime), CAST(N'2020-07-09T12:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000055', N'MF00000004', CAST(N'2020-07-10T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T12:50:26.000' AS DateTime), CAST(N'2020-07-10T12:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000056', N'MF00000004', CAST(N'2020-07-11T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T12:50:26.000' AS DateTime), CAST(N'2020-07-11T12:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000057', N'MF00000004', CAST(N'2020-07-12T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T12:50:26.000' AS DateTime), CAST(N'2020-07-12T12:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000058', N'MF00000004', CAST(N'2020-07-13T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T12:50:26.000' AS DateTime), CAST(N'2020-07-13T12:50:26.000' AS DateTime), CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(N'2020-07-13T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000059', N'MF00000004', CAST(N'2020-07-14T12:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T12:50:26.000' AS DateTime), CAST(N'2020-07-14T12:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000060', N'MF00000005', CAST(N'2020-06-30T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T06:50:26.000' AS DateTime), CAST(N'2020-06-30T06:50:26.000' AS DateTime), CAST(N'2020-06-30T08:50:26.000' AS DateTime), CAST(N'2020-06-30T09:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000061', N'MF00000005', CAST(N'2020-07-01T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T06:50:26.000' AS DateTime), CAST(N'2020-07-01T06:50:26.000' AS DateTime), CAST(N'2020-07-01T08:50:26.000' AS DateTime), CAST(N'2020-07-01T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000062', N'MF00000005', CAST(N'2020-07-02T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T06:50:26.000' AS DateTime), CAST(N'2020-07-02T06:50:26.000' AS DateTime), CAST(N'2020-07-02T08:50:26.000' AS DateTime), CAST(N'2020-07-02T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000063', N'MF00000005', CAST(N'2020-07-03T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T06:50:26.000' AS DateTime), CAST(N'2020-07-03T06:50:26.000' AS DateTime), CAST(N'2020-07-03T08:50:26.000' AS DateTime), CAST(N'2020-07-03T09:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000064', N'MF00000005', CAST(N'2020-07-04T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T06:50:26.000' AS DateTime), CAST(N'2020-07-04T06:50:26.000' AS DateTime), CAST(N'2020-07-04T08:50:26.000' AS DateTime), CAST(N'2020-07-04T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000065', N'MF00000005', CAST(N'2020-07-05T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T06:50:26.000' AS DateTime), CAST(N'2020-07-05T06:50:26.000' AS DateTime), CAST(N'2020-07-05T08:50:26.000' AS DateTime), CAST(N'2020-07-05T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000066', N'MF00000005', CAST(N'2020-07-06T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T06:50:26.000' AS DateTime), CAST(N'2020-07-06T06:50:26.000' AS DateTime), CAST(N'2020-07-06T08:50:26.000' AS DateTime), CAST(N'2020-07-06T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000067', N'MF00000005', CAST(N'2020-07-07T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T06:50:26.000' AS DateTime), CAST(N'2020-07-07T06:50:26.000' AS DateTime), CAST(N'2020-07-07T08:50:26.000' AS DateTime), CAST(N'2020-07-07T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000068', N'MF00000005', CAST(N'2020-07-08T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T06:50:26.000' AS DateTime), CAST(N'2020-07-08T06:50:26.000' AS DateTime), CAST(N'2020-07-08T08:50:26.000' AS DateTime), CAST(N'2020-07-08T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000069', N'MF00000005', CAST(N'2020-07-09T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T06:50:26.000' AS DateTime), CAST(N'2020-07-09T06:50:26.000' AS DateTime), CAST(N'2020-07-09T08:50:26.000' AS DateTime), CAST(N'2020-07-09T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000070', N'MF00000005', CAST(N'2020-07-10T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T06:50:26.000' AS DateTime), CAST(N'2020-07-10T06:50:26.000' AS DateTime), CAST(N'2020-07-10T08:50:26.000' AS DateTime), CAST(N'2020-07-10T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000071', N'MF00000005', CAST(N'2020-07-11T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T06:50:26.000' AS DateTime), CAST(N'2020-07-11T06:50:26.000' AS DateTime), CAST(N'2020-07-11T08:50:26.000' AS DateTime), CAST(N'2020-07-11T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000072', N'MF00000005', CAST(N'2020-07-12T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T06:50:26.000' AS DateTime), CAST(N'2020-07-12T06:50:26.000' AS DateTime), CAST(N'2020-07-12T08:50:26.000' AS DateTime), CAST(N'2020-07-12T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000073', N'MF00000005', CAST(N'2020-07-13T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T06:50:26.000' AS DateTime), CAST(N'2020-07-13T06:50:26.000' AS DateTime), CAST(N'2020-07-13T08:50:26.000' AS DateTime), CAST(N'2020-07-13T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000074', N'MF00000005', CAST(N'2020-07-14T06:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T06:50:26.000' AS DateTime), CAST(N'2020-07-14T06:50:26.000' AS DateTime), CAST(N'2020-07-14T08:50:26.000' AS DateTime), CAST(N'2020-07-14T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000075', N'MF00000006', CAST(N'2020-06-30T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T03:50:26.000' AS DateTime), CAST(N'2020-06-30T03:50:26.000' AS DateTime), CAST(N'2020-06-30T05:50:26.000' AS DateTime), CAST(N'2020-06-30T06:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000076', N'MF00000006', CAST(N'2020-07-01T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T03:50:26.000' AS DateTime), CAST(N'2020-07-01T03:50:26.000' AS DateTime), CAST(N'2020-07-01T05:50:26.000' AS DateTime), CAST(N'2020-07-01T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000077', N'MF00000006', CAST(N'2020-07-02T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T03:50:26.000' AS DateTime), CAST(N'2020-07-02T03:50:26.000' AS DateTime), CAST(N'2020-07-02T05:50:26.000' AS DateTime), CAST(N'2020-07-02T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000078', N'MF00000006', CAST(N'2020-07-03T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T03:50:26.000' AS DateTime), CAST(N'2020-07-03T03:50:26.000' AS DateTime), CAST(N'2020-07-03T05:50:26.000' AS DateTime), CAST(N'2020-07-03T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000079', N'MF00000006', CAST(N'2020-07-04T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T03:50:26.000' AS DateTime), CAST(N'2020-07-04T03:50:26.000' AS DateTime), CAST(N'2020-07-04T05:50:26.000' AS DateTime), CAST(N'2020-07-04T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000080', N'MF00000006', CAST(N'2020-07-05T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T03:50:26.000' AS DateTime), CAST(N'2020-07-05T03:50:26.000' AS DateTime), CAST(N'2020-07-05T05:50:26.000' AS DateTime), CAST(N'2020-07-05T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000081', N'MF00000006', CAST(N'2020-07-06T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T03:50:26.000' AS DateTime), CAST(N'2020-07-06T03:50:26.000' AS DateTime), CAST(N'2020-07-06T05:50:26.000' AS DateTime), CAST(N'2020-07-06T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000082', N'MF00000006', CAST(N'2020-07-07T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T03:50:26.000' AS DateTime), CAST(N'2020-07-07T03:50:26.000' AS DateTime), CAST(N'2020-07-07T05:50:26.000' AS DateTime), CAST(N'2020-07-07T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000083', N'MF00000006', CAST(N'2020-07-08T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T03:50:26.000' AS DateTime), CAST(N'2020-07-08T03:50:26.000' AS DateTime), CAST(N'2020-07-08T05:50:26.000' AS DateTime), CAST(N'2020-07-08T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000084', N'MF00000006', CAST(N'2020-07-09T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T03:50:26.000' AS DateTime), CAST(N'2020-07-09T03:50:26.000' AS DateTime), CAST(N'2020-07-09T05:50:26.000' AS DateTime), CAST(N'2020-07-09T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000085', N'MF00000006', CAST(N'2020-07-10T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T03:50:26.000' AS DateTime), CAST(N'2020-07-10T03:50:26.000' AS DateTime), CAST(N'2020-07-10T05:50:26.000' AS DateTime), CAST(N'2020-07-10T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000086', N'MF00000006', CAST(N'2020-07-11T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T03:50:26.000' AS DateTime), CAST(N'2020-07-11T03:50:26.000' AS DateTime), CAST(N'2020-07-11T05:50:26.000' AS DateTime), CAST(N'2020-07-11T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000087', N'MF00000006', CAST(N'2020-07-12T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T03:50:26.000' AS DateTime), CAST(N'2020-07-12T03:50:26.000' AS DateTime), CAST(N'2020-07-12T05:50:26.000' AS DateTime), CAST(N'2020-07-12T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000088', N'MF00000006', CAST(N'2020-07-13T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T03:50:26.000' AS DateTime), CAST(N'2020-07-13T03:50:26.000' AS DateTime), CAST(N'2020-07-13T05:50:26.000' AS DateTime), CAST(N'2020-07-13T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000089', N'MF00000006', CAST(N'2020-07-14T03:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T03:50:26.000' AS DateTime), CAST(N'2020-07-14T03:50:26.000' AS DateTime), CAST(N'2020-07-14T05:50:26.000' AS DateTime), CAST(N'2020-07-14T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000090', N'MF00000007', CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(N'2020-06-30T19:50:26.000' AS DateTime), CAST(N'2020-06-30T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000091', N'MF00000007', CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(N'2020-07-01T19:50:26.000' AS DateTime), CAST(N'2020-07-01T20:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000092', N'MF00000007', CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(N'2020-07-02T19:50:26.000' AS DateTime), CAST(N'2020-07-02T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000093', N'MF00000007', CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(N'2020-07-03T19:50:26.000' AS DateTime), CAST(N'2020-07-03T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000094', N'MF00000007', CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(N'2020-07-04T19:50:26.000' AS DateTime), CAST(N'2020-07-04T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000095', N'MF00000007', CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(N'2020-07-05T19:50:26.000' AS DateTime), CAST(N'2020-07-05T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000096', N'MF00000007', CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(N'2020-07-06T19:50:26.000' AS DateTime), CAST(N'2020-07-06T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000097', N'MF00000007', CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(N'2020-07-07T19:50:26.000' AS DateTime), CAST(N'2020-07-07T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000098', N'MF00000007', CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(N'2020-07-08T19:50:26.000' AS DateTime), CAST(N'2020-07-08T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000099', N'MF00000007', CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(N'2020-07-09T19:50:26.000' AS DateTime), CAST(N'2020-07-09T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000100', N'MF00000007', CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(N'2020-07-10T19:50:26.000' AS DateTime), CAST(N'2020-07-10T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000101', N'MF00000007', CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(N'2020-07-11T19:50:26.000' AS DateTime), CAST(N'2020-07-11T20:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000102', N'MF00000007', CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(N'2020-07-12T19:50:26.000' AS DateTime), CAST(N'2020-07-12T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000103', N'MF00000007', CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(N'2020-07-13T19:50:26.000' AS DateTime), CAST(N'2020-07-13T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000104', N'MF00000007', CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(N'2020-07-14T19:50:26.000' AS DateTime), CAST(N'2020-07-14T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000105', N'MF00000008', CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(N'2020-06-30T16:50:26.000' AS DateTime), CAST(N'2020-06-30T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000106', N'MF00000008', CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(N'2020-07-01T16:50:26.000' AS DateTime), CAST(N'2020-07-01T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000107', N'MF00000008', CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(N'2020-07-02T16:50:26.000' AS DateTime), CAST(N'2020-07-02T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000108', N'MF00000008', CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(N'2020-07-03T16:50:26.000' AS DateTime), CAST(N'2020-07-03T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000109', N'MF00000008', CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(N'2020-07-04T16:50:26.000' AS DateTime), CAST(N'2020-07-04T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000110', N'MF00000008', CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(N'2020-07-05T16:50:26.000' AS DateTime), CAST(N'2020-07-05T17:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000111', N'MF00000008', CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(N'2020-07-06T16:50:26.000' AS DateTime), CAST(N'2020-07-06T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000112', N'MF00000008', CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(N'2020-07-07T16:50:26.000' AS DateTime), CAST(N'2020-07-07T17:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000113', N'MF00000008', CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(N'2020-07-08T16:50:26.000' AS DateTime), CAST(N'2020-07-08T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000114', N'MF00000008', CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(N'2020-07-09T16:50:26.000' AS DateTime), CAST(N'2020-07-09T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000115', N'MF00000008', CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(N'2020-07-10T16:50:26.000' AS DateTime), CAST(N'2020-07-10T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000116', N'MF00000008', CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(N'2020-07-11T16:50:26.000' AS DateTime), CAST(N'2020-07-11T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000117', N'MF00000008', CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(N'2020-07-12T16:50:26.000' AS DateTime), CAST(N'2020-07-12T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000118', N'MF00000008', CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(N'2020-07-13T16:50:26.000' AS DateTime), CAST(N'2020-07-13T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000119', N'MF00000008', CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(N'2020-07-14T16:50:26.000' AS DateTime), CAST(N'2020-07-14T16:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000120', N'MF00000009', CAST(N'2020-06-30T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T15:50:26.000' AS DateTime), CAST(N'2020-06-30T15:50:26.000' AS DateTime), CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(N'2020-06-30T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000121', N'MF00000009', CAST(N'2020-07-01T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T15:50:26.000' AS DateTime), CAST(N'2020-07-01T15:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000122', N'MF00000009', CAST(N'2020-07-02T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T15:50:26.000' AS DateTime), CAST(N'2020-07-02T15:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000123', N'MF00000009', CAST(N'2020-07-03T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T15:50:26.000' AS DateTime), CAST(N'2020-07-03T15:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000124', N'MF00000009', CAST(N'2020-07-04T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T15:50:26.000' AS DateTime), CAST(N'2020-07-04T15:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000125', N'MF00000009', CAST(N'2020-07-05T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T15:50:26.000' AS DateTime), CAST(N'2020-07-05T15:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000126', N'MF00000009', CAST(N'2020-07-06T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T15:50:26.000' AS DateTime), CAST(N'2020-07-06T15:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000127', N'MF00000009', CAST(N'2020-07-07T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T15:50:26.000' AS DateTime), CAST(N'2020-07-07T15:50:26.000' AS DateTime), CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(N'2020-07-07T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000128', N'MF00000009', CAST(N'2020-07-08T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T15:50:26.000' AS DateTime), CAST(N'2020-07-08T15:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000129', N'MF00000009', CAST(N'2020-07-09T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T15:50:26.000' AS DateTime), CAST(N'2020-07-09T15:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000130', N'MF00000009', CAST(N'2020-07-10T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T15:50:26.000' AS DateTime), CAST(N'2020-07-10T15:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000131', N'MF00000009', CAST(N'2020-07-11T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T15:50:26.000' AS DateTime), CAST(N'2020-07-11T15:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000132', N'MF00000009', CAST(N'2020-07-12T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T15:50:26.000' AS DateTime), CAST(N'2020-07-12T15:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000133', N'MF00000009', CAST(N'2020-07-13T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T15:50:26.000' AS DateTime), CAST(N'2020-07-13T15:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000134', N'MF00000009', CAST(N'2020-07-14T15:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T15:50:26.000' AS DateTime), CAST(N'2020-07-14T15:50:26.000' AS DateTime), CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(N'2020-07-14T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000135', N'MF00000010', CAST(N'2020-06-30T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T13:50:26.000' AS DateTime), CAST(N'2020-06-30T13:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000136', N'MF00000010', CAST(N'2020-07-01T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T13:50:26.000' AS DateTime), CAST(N'2020-07-01T13:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000137', N'MF00000010', CAST(N'2020-07-02T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T13:50:26.000' AS DateTime), CAST(N'2020-07-02T13:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000138', N'MF00000010', CAST(N'2020-07-03T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T13:50:26.000' AS DateTime), CAST(N'2020-07-03T13:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000139', N'MF00000010', CAST(N'2020-07-04T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T13:50:26.000' AS DateTime), CAST(N'2020-07-04T13:50:26.000' AS DateTime), CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(N'2020-07-04T15:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000140', N'MF00000010', CAST(N'2020-07-05T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T13:50:26.000' AS DateTime), CAST(N'2020-07-05T13:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000141', N'MF00000010', CAST(N'2020-07-06T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T13:50:26.000' AS DateTime), CAST(N'2020-07-06T13:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000142', N'MF00000010', CAST(N'2020-07-07T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T13:50:26.000' AS DateTime), CAST(N'2020-07-07T13:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000143', N'MF00000010', CAST(N'2020-07-08T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T13:50:26.000' AS DateTime), CAST(N'2020-07-08T13:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000144', N'MF00000010', CAST(N'2020-07-09T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T13:50:26.000' AS DateTime), CAST(N'2020-07-09T13:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000145', N'MF00000010', CAST(N'2020-07-10T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T13:50:26.000' AS DateTime), CAST(N'2020-07-10T13:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000146', N'MF00000010', CAST(N'2020-07-11T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T13:50:26.000' AS DateTime), CAST(N'2020-07-11T13:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000147', N'MF00000010', CAST(N'2020-07-12T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T13:50:26.000' AS DateTime), CAST(N'2020-07-12T13:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000148', N'MF00000010', CAST(N'2020-07-13T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T13:50:26.000' AS DateTime), CAST(N'2020-07-13T13:50:26.000' AS DateTime), CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(N'2020-07-13T15:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000149', N'MF00000010', CAST(N'2020-07-14T13:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T13:50:26.000' AS DateTime), CAST(N'2020-07-14T13:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000150', N'MF00000011', CAST(N'2020-06-30T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T16:50:26.000' AS DateTime), CAST(N'2020-06-30T16:50:26.000' AS DateTime), CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(N'2020-06-30T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000151', N'MF00000011', CAST(N'2020-07-01T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T16:50:26.000' AS DateTime), CAST(N'2020-07-01T16:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000152', N'MF00000011', CAST(N'2020-07-02T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T16:50:26.000' AS DateTime), CAST(N'2020-07-02T16:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000153', N'MF00000011', CAST(N'2020-07-03T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T16:50:26.000' AS DateTime), CAST(N'2020-07-03T16:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000154', N'MF00000011', CAST(N'2020-07-04T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T16:50:26.000' AS DateTime), CAST(N'2020-07-04T16:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000155', N'MF00000011', CAST(N'2020-07-05T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T16:50:26.000' AS DateTime), CAST(N'2020-07-05T16:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000156', N'MF00000011', CAST(N'2020-07-06T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T16:50:26.000' AS DateTime), CAST(N'2020-07-06T16:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000157', N'MF00000011', CAST(N'2020-07-07T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T16:50:26.000' AS DateTime), CAST(N'2020-07-07T16:50:26.000' AS DateTime), CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(N'2020-07-07T19:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000158', N'MF00000011', CAST(N'2020-07-08T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T16:50:26.000' AS DateTime), CAST(N'2020-07-08T16:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000159', N'MF00000011', CAST(N'2020-07-09T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T16:50:26.000' AS DateTime), CAST(N'2020-07-09T16:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000160', N'MF00000011', CAST(N'2020-07-10T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T16:50:26.000' AS DateTime), CAST(N'2020-07-10T16:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000161', N'MF00000011', CAST(N'2020-07-11T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T16:50:26.000' AS DateTime), CAST(N'2020-07-11T16:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000162', N'MF00000011', CAST(N'2020-07-12T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T16:50:26.000' AS DateTime), CAST(N'2020-07-12T16:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000163', N'MF00000011', CAST(N'2020-07-13T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T16:50:26.000' AS DateTime), CAST(N'2020-07-13T16:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000164', N'MF00000011', CAST(N'2020-07-14T16:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T16:50:26.000' AS DateTime), CAST(N'2020-07-14T16:50:26.000' AS DateTime), CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(N'2020-07-14T18:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000165', N'MF00000012', CAST(N'2020-06-30T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T10:50:26.000' AS DateTime), CAST(N'2020-06-30T10:50:26.000' AS DateTime), CAST(N'2020-06-30T12:50:26.000' AS DateTime), CAST(N'2020-06-30T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000166', N'MF00000012', CAST(N'2020-07-01T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T10:50:26.000' AS DateTime), CAST(N'2020-07-01T10:50:26.000' AS DateTime), CAST(N'2020-07-01T12:50:26.000' AS DateTime), CAST(N'2020-07-01T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000167', N'MF00000012', CAST(N'2020-07-02T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T10:50:26.000' AS DateTime), CAST(N'2020-07-02T10:50:26.000' AS DateTime), CAST(N'2020-07-02T12:50:26.000' AS DateTime), CAST(N'2020-07-02T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000168', N'MF00000012', CAST(N'2020-07-03T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T10:50:26.000' AS DateTime), CAST(N'2020-07-03T10:50:26.000' AS DateTime), CAST(N'2020-07-03T12:50:26.000' AS DateTime), CAST(N'2020-07-03T13:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000169', N'MF00000012', CAST(N'2020-07-04T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T10:50:26.000' AS DateTime), CAST(N'2020-07-04T10:50:26.000' AS DateTime), CAST(N'2020-07-04T12:50:26.000' AS DateTime), CAST(N'2020-07-04T13:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000170', N'MF00000012', CAST(N'2020-07-05T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T10:50:26.000' AS DateTime), CAST(N'2020-07-05T10:50:26.000' AS DateTime), CAST(N'2020-07-05T12:50:26.000' AS DateTime), CAST(N'2020-07-05T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000171', N'MF00000012', CAST(N'2020-07-06T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T10:50:26.000' AS DateTime), CAST(N'2020-07-06T10:50:26.000' AS DateTime), CAST(N'2020-07-06T12:50:26.000' AS DateTime), CAST(N'2020-07-06T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000172', N'MF00000012', CAST(N'2020-07-07T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T10:50:26.000' AS DateTime), CAST(N'2020-07-07T10:50:26.000' AS DateTime), CAST(N'2020-07-07T12:50:26.000' AS DateTime), CAST(N'2020-07-07T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000173', N'MF00000012', CAST(N'2020-07-08T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T10:50:26.000' AS DateTime), CAST(N'2020-07-08T10:50:26.000' AS DateTime), CAST(N'2020-07-08T12:50:26.000' AS DateTime), CAST(N'2020-07-08T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000174', N'MF00000012', CAST(N'2020-07-09T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T10:50:26.000' AS DateTime), CAST(N'2020-07-09T10:50:26.000' AS DateTime), CAST(N'2020-07-09T12:50:26.000' AS DateTime), CAST(N'2020-07-09T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000175', N'MF00000012', CAST(N'2020-07-10T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T10:50:26.000' AS DateTime), CAST(N'2020-07-10T10:50:26.000' AS DateTime), CAST(N'2020-07-10T12:50:26.000' AS DateTime), CAST(N'2020-07-10T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000176', N'MF00000012', CAST(N'2020-07-11T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T10:50:26.000' AS DateTime), CAST(N'2020-07-11T10:50:26.000' AS DateTime), CAST(N'2020-07-11T12:50:26.000' AS DateTime), CAST(N'2020-07-11T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000177', N'MF00000012', CAST(N'2020-07-12T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T10:50:26.000' AS DateTime), CAST(N'2020-07-12T10:50:26.000' AS DateTime), CAST(N'2020-07-12T12:50:26.000' AS DateTime), CAST(N'2020-07-12T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000178', N'MF00000012', CAST(N'2020-07-13T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T10:50:26.000' AS DateTime), CAST(N'2020-07-13T10:50:26.000' AS DateTime), CAST(N'2020-07-13T12:50:26.000' AS DateTime), CAST(N'2020-07-13T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000179', N'MF00000012', CAST(N'2020-07-14T10:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T10:50:26.000' AS DateTime), CAST(N'2020-07-14T10:50:26.000' AS DateTime), CAST(N'2020-07-14T12:50:26.000' AS DateTime), CAST(N'2020-07-14T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000180', N'MF00000013', CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T04:50:26.000' AS DateTime), CAST(N'2020-06-30T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000181', N'MF00000013', CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T04:50:26.000' AS DateTime), CAST(N'2020-07-01T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000182', N'MF00000013', CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T04:50:26.000' AS DateTime), CAST(N'2020-07-02T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000183', N'MF00000013', CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T04:50:26.000' AS DateTime), CAST(N'2020-07-03T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000184', N'MF00000013', CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T04:50:26.000' AS DateTime), CAST(N'2020-07-04T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000185', N'MF00000013', CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T04:50:26.000' AS DateTime), CAST(N'2020-07-05T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000186', N'MF00000013', CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T04:50:26.000' AS DateTime), CAST(N'2020-07-06T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000187', N'MF00000013', CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T04:50:26.000' AS DateTime), CAST(N'2020-07-07T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000188', N'MF00000013', CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T04:50:26.000' AS DateTime), CAST(N'2020-07-08T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000189', N'MF00000013', CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T04:50:26.000' AS DateTime), CAST(N'2020-07-09T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000190', N'MF00000013', CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T04:50:26.000' AS DateTime), CAST(N'2020-07-10T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000191', N'MF00000013', CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T04:50:26.000' AS DateTime), CAST(N'2020-07-11T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000192', N'MF00000013', CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T04:50:26.000' AS DateTime), CAST(N'2020-07-12T05:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000193', N'MF00000013', CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T04:50:26.000' AS DateTime), CAST(N'2020-07-13T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000194', N'MF00000013', CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T04:50:26.000' AS DateTime), CAST(N'2020-07-14T04:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000195', N'MF00000014', CAST(N'2020-06-30T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T09:50:26.000' AS DateTime), CAST(N'2020-06-30T09:50:26.000' AS DateTime), CAST(N'2020-06-30T11:50:26.000' AS DateTime), CAST(N'2020-06-30T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000196', N'MF00000014', CAST(N'2020-07-01T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T09:50:26.000' AS DateTime), CAST(N'2020-07-01T09:50:26.000' AS DateTime), CAST(N'2020-07-01T11:50:26.000' AS DateTime), CAST(N'2020-07-01T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000197', N'MF00000014', CAST(N'2020-07-02T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T09:50:26.000' AS DateTime), CAST(N'2020-07-02T09:50:26.000' AS DateTime), CAST(N'2020-07-02T11:50:26.000' AS DateTime), CAST(N'2020-07-02T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000198', N'MF00000014', CAST(N'2020-07-03T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T09:50:26.000' AS DateTime), CAST(N'2020-07-03T09:50:26.000' AS DateTime), CAST(N'2020-07-03T11:50:26.000' AS DateTime), CAST(N'2020-07-03T12:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000199', N'MF00000014', CAST(N'2020-07-04T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T09:50:26.000' AS DateTime), CAST(N'2020-07-04T09:50:26.000' AS DateTime), CAST(N'2020-07-04T11:50:26.000' AS DateTime), CAST(N'2020-07-04T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000200', N'MF00000014', CAST(N'2020-07-05T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T09:50:26.000' AS DateTime), CAST(N'2020-07-05T09:50:26.000' AS DateTime), CAST(N'2020-07-05T11:50:26.000' AS DateTime), CAST(N'2020-07-05T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000201', N'MF00000014', CAST(N'2020-07-06T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T09:50:26.000' AS DateTime), CAST(N'2020-07-06T09:50:26.000' AS DateTime), CAST(N'2020-07-06T11:50:26.000' AS DateTime), CAST(N'2020-07-06T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000202', N'MF00000014', CAST(N'2020-07-07T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T09:50:26.000' AS DateTime), CAST(N'2020-07-07T09:50:26.000' AS DateTime), CAST(N'2020-07-07T11:50:26.000' AS DateTime), CAST(N'2020-07-07T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000203', N'MF00000014', CAST(N'2020-07-08T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T09:50:26.000' AS DateTime), CAST(N'2020-07-08T09:50:26.000' AS DateTime), CAST(N'2020-07-08T11:50:26.000' AS DateTime), CAST(N'2020-07-08T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000204', N'MF00000014', CAST(N'2020-07-09T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T09:50:26.000' AS DateTime), CAST(N'2020-07-09T09:50:26.000' AS DateTime), CAST(N'2020-07-09T11:50:26.000' AS DateTime), CAST(N'2020-07-09T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000205', N'MF00000014', CAST(N'2020-07-10T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T09:50:26.000' AS DateTime), CAST(N'2020-07-10T09:50:26.000' AS DateTime), CAST(N'2020-07-10T11:50:26.000' AS DateTime), CAST(N'2020-07-10T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000206', N'MF00000014', CAST(N'2020-07-11T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T09:50:26.000' AS DateTime), CAST(N'2020-07-11T09:50:26.000' AS DateTime), CAST(N'2020-07-11T11:50:26.000' AS DateTime), CAST(N'2020-07-11T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000207', N'MF00000014', CAST(N'2020-07-12T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T09:50:26.000' AS DateTime), CAST(N'2020-07-12T09:50:26.000' AS DateTime), CAST(N'2020-07-12T11:50:26.000' AS DateTime), CAST(N'2020-07-12T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000208', N'MF00000014', CAST(N'2020-07-13T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T09:50:26.000' AS DateTime), CAST(N'2020-07-13T09:50:26.000' AS DateTime), CAST(N'2020-07-13T11:50:26.000' AS DateTime), CAST(N'2020-07-13T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000209', N'MF00000014', CAST(N'2020-07-14T09:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T09:50:26.000' AS DateTime), CAST(N'2020-07-14T09:50:26.000' AS DateTime), CAST(N'2020-07-14T11:50:26.000' AS DateTime), CAST(N'2020-07-14T11:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000210', N'MF00000015', CAST(N'2020-06-30T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-06-30T04:50:26.000' AS DateTime), CAST(N'2020-06-30T04:50:26.000' AS DateTime), CAST(N'2020-06-30T07:50:26.000' AS DateTime), CAST(N'2020-06-30T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000211', N'MF00000015', CAST(N'2020-07-01T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-01T04:50:26.000' AS DateTime), CAST(N'2020-07-01T04:50:26.000' AS DateTime), CAST(N'2020-07-01T07:50:26.000' AS DateTime), CAST(N'2020-07-01T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000212', N'MF00000015', CAST(N'2020-07-02T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-02T04:50:26.000' AS DateTime), CAST(N'2020-07-02T04:50:26.000' AS DateTime), CAST(N'2020-07-02T07:50:26.000' AS DateTime), CAST(N'2020-07-02T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000213', N'MF00000015', CAST(N'2020-07-03T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-03T04:50:26.000' AS DateTime), CAST(N'2020-07-03T04:50:26.000' AS DateTime), CAST(N'2020-07-03T07:50:26.000' AS DateTime), CAST(N'2020-07-03T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000214', N'MF00000015', CAST(N'2020-07-04T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-04T04:50:26.000' AS DateTime), CAST(N'2020-07-04T04:50:26.000' AS DateTime), CAST(N'2020-07-04T07:50:26.000' AS DateTime), CAST(N'2020-07-04T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000215', N'MF00000015', CAST(N'2020-07-05T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-05T04:50:26.000' AS DateTime), CAST(N'2020-07-05T04:50:26.000' AS DateTime), CAST(N'2020-07-05T07:50:26.000' AS DateTime), CAST(N'2020-07-05T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000216', N'MF00000015', CAST(N'2020-07-06T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-06T04:50:26.000' AS DateTime), CAST(N'2020-07-06T04:50:26.000' AS DateTime), CAST(N'2020-07-06T07:50:26.000' AS DateTime), CAST(N'2020-07-06T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000217', N'MF00000015', CAST(N'2020-07-07T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-07T04:50:26.000' AS DateTime), CAST(N'2020-07-07T04:50:26.000' AS DateTime), CAST(N'2020-07-07T07:50:26.000' AS DateTime), CAST(N'2020-07-07T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000218', N'MF00000015', CAST(N'2020-07-08T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-08T04:50:26.000' AS DateTime), CAST(N'2020-07-08T04:50:26.000' AS DateTime), CAST(N'2020-07-08T07:50:26.000' AS DateTime), CAST(N'2020-07-08T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000219', N'MF00000015', CAST(N'2020-07-09T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-09T04:50:26.000' AS DateTime), CAST(N'2020-07-09T04:50:26.000' AS DateTime), CAST(N'2020-07-09T07:50:26.000' AS DateTime), CAST(N'2020-07-09T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000220', N'MF00000015', CAST(N'2020-07-10T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-10T04:50:26.000' AS DateTime), CAST(N'2020-07-10T04:50:26.000' AS DateTime), CAST(N'2020-07-10T07:50:26.000' AS DateTime), CAST(N'2020-07-10T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000221', N'MF00000015', CAST(N'2020-07-11T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-11T04:50:26.000' AS DateTime), CAST(N'2020-07-11T04:50:26.000' AS DateTime), CAST(N'2020-07-11T07:50:26.000' AS DateTime), CAST(N'2020-07-11T08:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000222', N'MF00000015', CAST(N'2020-07-12T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-12T04:50:26.000' AS DateTime), CAST(N'2020-07-12T04:50:26.000' AS DateTime), CAST(N'2020-07-12T07:50:26.000' AS DateTime), CAST(N'2020-07-12T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000223', N'MF00000015', CAST(N'2020-07-13T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-13T04:50:26.000' AS DateTime), CAST(N'2020-07-13T04:50:26.000' AS DateTime), CAST(N'2020-07-13T07:50:26.000' AS DateTime), CAST(N'2020-07-13T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[executiveFlight] ([executiveFlightId], [flightId], [executiveDate], [executivePrice], [flightStatus], [ETD], [ATD], [ETA], [ATA], [boardingGate], [boardingTime]) VALUES (N'1000000224', N'MF00000015', CAST(N'2020-07-14T04:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)), N'计划', CAST(N'2020-07-14T04:50:26.000' AS DateTime), CAST(N'2020-07-14T04:50:26.000' AS DateTime), CAST(N'2020-07-14T07:50:26.000' AS DateTime), CAST(N'2020-07-14T07:50:26.000' AS DateTime), N'', NULL)
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000001', N'波音737700', 2, 14, CAST(N'2020-06-26T02:50:25.000' AS DateTime), CAST(N'2020-06-26T03:50:25.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000002', N'波音737700', 1, 14, CAST(N'2020-06-26T17:50:25.000' AS DateTime), CAST(N'2020-06-26T18:50:25.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000003', N'波音737700', 1, 14, CAST(N'2020-06-26T01:50:26.000' AS DateTime), CAST(N'2020-06-26T02:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000004', N'波音737700', 2, 14, CAST(N'2020-06-26T12:50:26.000' AS DateTime), CAST(N'2020-06-26T14:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000005', N'波音737700', 1, 14, CAST(N'2020-06-26T06:50:26.000' AS DateTime), CAST(N'2020-06-26T08:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000006', N'波音737700', 2, 13, CAST(N'2020-06-26T03:50:26.000' AS DateTime), CAST(N'2020-06-26T05:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000007', N'波音737700', 1, 13, CAST(N'2020-06-26T18:50:26.000' AS DateTime), CAST(N'2020-06-26T19:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000008', N'波音737700', 2, 13, CAST(N'2020-06-26T14:50:26.000' AS DateTime), CAST(N'2020-06-26T16:50:26.000' AS DateTime), CAST(1100.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000009', N'波音737700', 2, 13, CAST(N'2020-06-26T15:50:26.000' AS DateTime), CAST(N'2020-06-26T18:50:26.000' AS DateTime), CAST(800.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000010', N'波音737700', 2, 13, CAST(N'2020-06-26T13:50:26.000' AS DateTime), CAST(N'2020-06-26T14:50:26.000' AS DateTime), CAST(600.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000011', N'波音737700', 1, 4, CAST(N'2020-06-26T16:50:26.000' AS DateTime), CAST(N'2020-06-26T18:50:26.000' AS DateTime), CAST(700.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000012', N'波音737700', 2, 4, CAST(N'2020-06-26T10:50:26.000' AS DateTime), CAST(N'2020-06-26T12:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000013', N'波音737700', 1, 4, CAST(N'2020-06-26T01:50:26.000' AS DateTime), CAST(N'2020-06-26T04:50:26.000' AS DateTime), CAST(1200.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000014', N'波音737700', 1, 4, CAST(N'2020-06-26T09:50:26.000' AS DateTime), CAST(N'2020-06-26T11:50:26.000' AS DateTime), CAST(400.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[flight] ([flightId], [modelId], [terminalId], [ter_terminalId], [plannedDepartureTtime], [plannedArrivalTime], [pricing]) VALUES (N'MF00000015', N'波音737700', 2, 4, CAST(N'2020-06-26T04:50:26.000' AS DateTime), CAST(N'2020-06-26T07:50:26.000' AS DateTime), CAST(900.00 AS Numeric(8, 2)))
GO
INSERT [dbo].[model] ([modelId], [modelName]) VALUES (N'波音000001', N'')
GO
INSERT [dbo].[model] ([modelId], [modelName]) VALUES (N'波音737700', N'Boeing 737')
GO
SET IDENTITY_INSERT [dbo].[orders] ON 
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (174408605, 2, 0, CAST(250.00 AS Numeric(8, 2)), N'已支付', N'13695236674', CAST(N'2020-06-26T20:26:48.607' AS DateTime), CAST(N'2020-06-26T20:26:48.707' AS DateTime), N'张三')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (174602079, 2, 0, CAST(870.00 AS Numeric(8, 2)), N'已支付', N'13628074985', CAST(N'2020-06-26T20:30:02.080' AS DateTime), CAST(N'2020-06-26T20:30:02.197' AS DateTime), N'杨琴')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (177443429, 2, 20, CAST(350.00 AS Numeric(8, 2)), N'已支付', N'13628074985', CAST(N'2020-06-26T21:17:23.430' AS DateTime), CAST(N'2020-06-26T21:17:23.680' AS DateTime), N'杨琴')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (178662857, 2, 2, CAST(948.00 AS Numeric(8, 2)), N'已支付', N'15647820153', CAST(N'2020-06-26T21:37:42.857' AS DateTime), CAST(N'2020-06-26T21:37:43.800' AS DateTime), N'郑奇')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (178811164, 2, 90, CAST(610.00 AS Numeric(8, 2)), N'已支付', N'19254301879', CAST(N'2020-06-26T21:40:11.163' AS DateTime), CAST(N'2020-06-26T21:40:12.213' AS DateTime), N'李华')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179064697, 2, 60, CAST(410.00 AS Numeric(8, 2)), N'已支付', N'13695236674', CAST(N'2020-06-26T21:44:24.697' AS DateTime), CAST(N'2020-06-26T21:44:25.440' AS DateTime), N'张三')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179233212, 2, 40, CAST(710.00 AS Numeric(8, 2)), N'已支付', N'19254301879', CAST(N'2020-06-26T21:47:13.213' AS DateTime), CAST(N'2020-06-26T21:47:14.863' AS DateTime), N'李华')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179423913, 2, 60, CAST(840.00 AS Numeric(8, 2)), N'已支付', N'15647820153', CAST(N'2020-06-26T21:50:23.913' AS DateTime), CAST(N'2020-06-26T21:50:25.037' AS DateTime), N'郑奇')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179565520, 2, 80, CAST(420.00 AS Numeric(8, 2)), N'已支付', N'13639029262', CAST(N'2020-06-26T21:52:45.520' AS DateTime), CAST(N'2020-06-26T21:52:46.587' AS DateTime), N'郭萍')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179674393, 2, 40, CAST(1700.00 AS Numeric(8, 2)), N'已支付', N'13520149875', CAST(N'2020-06-26T21:54:34.393' AS DateTime), CAST(N'2020-06-26T21:54:35.517' AS DateTime), N'孟华')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (244567990, 2, 20, CAST(1520.00 AS Numeric(8, 2)), N'已支付', N'19254301879', CAST(N'2020-06-27T15:56:07.990' AS DateTime), CAST(N'2020-06-27T15:56:08.267' AS DateTime), N'李华')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179328905, 2, 60, CAST(810.00 AS Numeric(8, 2)), N'已支付', N'13654208741', CAST(N'2020-06-26T21:48:48.907' AS DateTime), CAST(N'2020-06-26T21:48:50.287' AS DateTime), N'马军')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179389419, 2, 80, CAST(570.00 AS Numeric(8, 2)), N'已支付', N'13628074985', CAST(N'2020-06-26T21:49:49.420' AS DateTime), CAST(N'2020-06-26T21:49:50.237' AS DateTime), N'杨琴')
GO
INSERT [dbo].[orders] ([orderId], [userId], [offsetIntegral], [totalCost], [orderStatusx], [telephone], [createTime], [paidTime], [linkman]) VALUES (179768758, 2, 160, CAST(90.00 AS Numeric(8, 2)), N'已支付', N'13520987416', CAST(N'2020-06-26T21:56:08.757' AS DateTime), CAST(N'2020-06-26T21:56:09.400' AS DateTime), N'张语琪')
GO
SET IDENTITY_INSERT [dbo].[orders] OFF
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'350181200005211771', N'1', N'男', N'101111     ', N'1')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'520103200002174411', N'吴泽龙', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'520103200001010666', N'张三', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'630279200006165389', N'张三', NULL, N'13695236674', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'365412199604254789', N'李四', NULL, N'13698745201', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'36541019950524321X', N'刘乐', NULL, N'13520148961', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'415792198805251234', N'赵六', NULL, N'13542017852', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'236201199603164152', N'王琦', NULL, N'13652103478', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'245620200112211234', N'钱静', NULL, N'13542103687', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'987456199605215478', N'孙琪', NULL, N'15478520147', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'142685200011214587', N'李丽', NULL, N'15478521478', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'157426198805214587', N'郑时', NULL, N'13520147852', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'520103200002174410', N'吴泽龙', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'520134199802253654', N'林华', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'520103200002174431', N'李冰', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'365420199805217895', N'王思思', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'365201199805194569', N'刘丽', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'632598199408236525', N'钱华', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'412541198805214763', N'郭萍', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'578201196803257894', N'杨琴', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'478569199807285698', N'秦英', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'42856119840525321X', N'郑奇', NULL, N'15647820153', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'907824197911054921', N'杨琴', NULL, N'13628074985', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'12045320010523957X', N'李华', NULL, N'19254301879', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'475301199605123145', N'马军', NULL, N'13654208741', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'632014197505246874', N'郭萍', NULL, N'13639029262', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'72541019780625421X', N'田福', NULL, N'19854236510', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'741036199405266581', N'钱星', NULL, N'13520147852', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'521302199609101238', N'孟华', NULL, N'13520149875', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'14654119880521456X', N'刘欣', NULL, N'15624397851', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'452131199605214521', N'谭世成', NULL, N'13639023313', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'965478199602153217', N'张宇', NULL, N'19859217268', N'正常')
GO
INSERT [dbo].[passenger] ([passengerId], [passengerName], [passengerSex], [passengerTel], [creditStatus]) VALUES (N'754110198805201492', N'张语琪', NULL, N'13520987416', N'正常')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (35, N'福建')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (43, N'湖南')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (11, N'北京')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (12, N'天津')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (13, N'河北')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (14, N'山西')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (15, N'内蒙古')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (21, N'辽宁')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (22, N'吉林')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (23, N'黑龙江')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (31, N'上海')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (32, N'江苏')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (33, N'浙江')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (34, N'安徽')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (36, N'江西')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (37, N'山东')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (41, N'河南')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (42, N'湖北')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (44, N'广东')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (45, N'广西')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (46, N'海南')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (50, N'重庆')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (51, N'四川')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (52, N'贵州')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (53, N'云南')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (54, N'西藏')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (61, N'陕西')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (62, N'甘肃')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (63, N'青海')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (64, N'宁夏')
GO
INSERT [dbo].[province] ([provinceId], [provinceName]) VALUES (65, N'新疆')
GO
SET IDENTITY_INSERT [dbo].[seatingChart] ON 
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (131, N'波音737700', 2, N'11A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (132, N'波音737700', 2, N'11B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (133, N'波音737700', 2, N'11J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (134, N'波音737700', 2, N'11L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (135, N'波音737700', 2, N'12A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (136, N'波音737700', 2, N'12B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (137, N'波音737700', 2, N'12J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (138, N'波音737700', 2, N'12L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (139, N'波音737700', 3, N'41A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (140, N'波音737700', 3, N'41B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (141, N'波音737700', 3, N'41C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (142, N'波音737700', 3, N'41J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (143, N'波音737700', 3, N'41K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (144, N'波音737700', 3, N'41L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (145, N'波音737700', 3, N'42A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (146, N'波音737700', 3, N'42B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (147, N'波音737700', 3, N'42C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (148, N'波音737700', 3, N'42J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (149, N'波音737700', 3, N'42K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (150, N'波音737700', 3, N'42L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (151, N'波音737700', 3, N'43A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (152, N'波音737700', 3, N'43B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (153, N'波音737700', 3, N'43C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (154, N'波音737700', 3, N'43J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (155, N'波音737700', 3, N'43K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (156, N'波音737700', 3, N'43L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (157, N'波音737700', 3, N'44A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (158, N'波音737700', 3, N'44B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (159, N'波音737700', 3, N'44C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (160, N'波音737700', 3, N'44J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (161, N'波音737700', 3, N'44K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (162, N'波音737700', 3, N'44L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (163, N'波音737700', 3, N'45A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (164, N'波音737700', 3, N'45B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (165, N'波音737700', 3, N'45C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (166, N'波音737700', 3, N'45J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (167, N'波音737700', 3, N'45K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (168, N'波音737700', 3, N'45L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (169, N'波音737700', 3, N'46A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (170, N'波音737700', 3, N'46B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (171, N'波音737700', 3, N'46C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (172, N'波音737700', 3, N'46J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (173, N'波音737700', 3, N'46K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (174, N'波音737700', 3, N'46L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (175, N'波音737700', 3, N'47A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (176, N'波音737700', 3, N'47B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (177, N'波音737700', 3, N'47C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (178, N'波音737700', 3, N'47J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (179, N'波音737700', 3, N'47K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (180, N'波音737700', 3, N'47L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (181, N'波音737700', 3, N'48A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (182, N'波音737700', 3, N'48B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (183, N'波音737700', 3, N'48C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (184, N'波音737700', 3, N'48J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (185, N'波音737700', 3, N'48K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (186, N'波音737700', 3, N'48L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (187, N'波音737700', 3, N'49A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (188, N'波音737700', 3, N'49B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (189, N'波音737700', 3, N'49C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (190, N'波音737700', 3, N'49J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (191, N'波音737700', 3, N'49K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (192, N'波音737700', 3, N'49L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (193, N'波音737700', 3, N'50A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (194, N'波音737700', 3, N'50B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (195, N'波音737700', 3, N'50C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (196, N'波音737700', 3, N'50J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (197, N'波音737700', 3, N'50K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (198, N'波音737700', 3, N'50L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (199, N'波音737700', 3, N'51A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (200, N'波音737700', 3, N'51B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (201, N'波音737700', 3, N'51C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (202, N'波音737700', 3, N'51J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (203, N'波音737700', 3, N'51K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (204, N'波音737700', 3, N'51L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (205, N'波音737700', 3, N'52A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (206, N'波音737700', 3, N'52B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (207, N'波音737700', 3, N'52C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (208, N'波音737700', 3, N'52J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (209, N'波音737700', 3, N'52K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (210, N'波音737700', 3, N'52L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (211, N'波音737700', 3, N'53A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (212, N'波音737700', 3, N'53B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (213, N'波音737700', 3, N'53C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (214, N'波音737700', 3, N'53J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (215, N'波音737700', 3, N'53K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (216, N'波音737700', 3, N'53L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (217, N'波音737700', 3, N'54A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (218, N'波音737700', 3, N'54B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (219, N'波音737700', 3, N'54C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (220, N'波音737700', 3, N'54J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (221, N'波音737700', 3, N'54K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (222, N'波音737700', 3, N'54L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (223, N'波音737700', 3, N'55A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (224, N'波音737700', 3, N'55B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (225, N'波音737700', 3, N'55C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (226, N'波音737700', 3, N'55J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (227, N'波音737700', 3, N'55K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (228, N'波音737700', 3, N'55L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (229, N'波音737700', 3, N'56A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (230, N'波音737700', 3, N'56B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (231, N'波音737700', 3, N'56C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (232, N'波音737700', 3, N'56J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (233, N'波音737700', 3, N'56K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (234, N'波音737700', 3, N'56L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (235, N'波音737700', 3, N'57A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (236, N'波音737700', 3, N'57B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (237, N'波音737700', 3, N'57C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (238, N'波音737700', 3, N'57J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (239, N'波音737700', 3, N'57K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (240, N'波音737700', 3, N'57L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (241, N'波音737700', 3, N'58A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (242, N'波音737700', 3, N'58B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (243, N'波音737700', 3, N'58C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (244, N'波音737700', 3, N'58J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (245, N'波音737700', 3, N'58K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (246, N'波音737700', 3, N'58L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (247, N'波音737700', 3, N'59A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (248, N'波音737700', 3, N'59B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (249, N'波音737700', 3, N'59C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (250, N'波音737700', 3, N'59J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (251, N'波音737700', 3, N'59K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (252, N'波音737700', 3, N'59L')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (253, N'波音737700', 3, N'60A')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (254, N'波音737700', 3, N'60B')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (255, N'波音737700', 3, N'60C')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (256, N'波音737700', 3, N'60J')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (257, N'波音737700', 3, N'60K')
GO
INSERT [dbo].[seatingChart] ([seatId], [modelId], [cabinId], [position]) VALUES (258, N'波音737700', 3, N'60L')
GO
SET IDENTITY_INSERT [dbo].[seatingChart] OFF
GO
INSERT [dbo].[seatSelection] ([seatId], [executiveFlightId], [ticketId], [seatStatus]) VALUES (186, N'1000000205', 10000022, N'已选')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (1, 1, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (2, 1, N'T2')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (3, 2, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (4, 15, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (5, 7, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (6, 5, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (7, 13, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (8, 4, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (9, 6, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (10, 8, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (11, 9, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (12, 3, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (13, 12, N'T1')
GO
INSERT [dbo].[terminal] ([terminalId], [airportId], [terminalName]) VALUES (14, 11, N'T1')
GO
SET IDENTITY_INSERT [dbo].[ticket] ON 
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000004, 174408605, N'630279200006165389', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000005, 174602079, N'907824197911054921', 2, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(870.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000006, 177443429, N'907824197911054921', 3, N'1000000052', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(370.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000007, 178662857, N'42856119840525321X', 2, N'1000000111', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(950.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000008, 178811164, N'365412199604254789', 3, N'1000000030', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(350.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000009, 178811164, N'12045320010523957X', 3, N'1000000030', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(350.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000010, 179064697, N'630279200006165389', 3, N'1000000104', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(470.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000011, 179233212, N'12045320010523957X', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000013, 179233212, N'42856119840525321X', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000016, 179423913, N'42856119840525321X', 3, N'1000000009', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(450.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000017, 179423913, N'907824197911054921', 3, N'1000000009', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(450.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000018, 179565520, N'632014197505246874', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000019, 179565520, N'72541019780625421X', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000020, 179674393, N'741036199405266581', 2, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(870.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000021, 179674393, N'521302199609101238', 2, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(870.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000023, 244567990, N'12045320010523957X', 2, N'1000000175', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(770.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000024, 244567990, N'14654119880521456X', 2, N'1000000175', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(770.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000012, 179233212, N'365412199604254789', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000014, 179328905, N'475301199605123145', 2, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(20.00 AS Numeric(8, 2)), CAST(870.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000015, 179389419, N'907824197911054921', 2, N'1000000079', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(650.00 AS Numeric(8, 2)), NULL, N'未值机', NULL)
GO
INSERT [dbo].[ticket] ([ticketId], [orderId], [passengerId], [cabinId], [tic_executiveFlightId], [airportConstructionCost], [insuranceCost], [totalCost], [remarks], [checkStatus], [boardingId]) VALUES (10000022, 179768758, N'754110198805201492', 3, N'1000000205', CAST(50.00 AS Numeric(8, 2)), CAST(0.00 AS Numeric(8, 2)), CAST(250.00 AS Numeric(8, 2)), NULL, N'已值机', NULL)
GO
SET IDENTITY_INSERT [dbo].[ticket] OFF
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000000', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-05-30T02:50:25.000' AS DateTime), CAST(N'2020-06-30T02:50:25.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000001', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-01T02:50:25.000' AS DateTime), CAST(N'2020-07-01T02:50:25.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000002', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-02T02:50:25.000' AS DateTime), CAST(N'2020-07-02T02:50:25.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000003', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-03T02:50:25.000' AS DateTime), CAST(N'2020-07-03T02:50:25.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000004', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-04T02:50:25.000' AS DateTime), CAST(N'2020-07-04T02:50:25.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000005', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-05T02:50:25.000' AS DateTime), CAST(N'2020-07-05T02:50:25.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000006', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-06T02:50:25.000' AS DateTime), CAST(N'2020-07-06T02:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000007', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-07T02:50:25.000' AS DateTime), CAST(N'2020-07-07T02:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000008', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-08T02:50:25.000' AS DateTime), CAST(N'2020-07-08T02:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000009', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-09T02:50:25.000' AS DateTime), CAST(N'2020-07-09T02:50:25.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000010', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-10T02:50:25.000' AS DateTime), CAST(N'2020-07-10T02:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000011', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-11T02:50:25.000' AS DateTime), CAST(N'2020-07-11T02:50:25.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000012', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-12T02:50:25.000' AS DateTime), CAST(N'2020-07-12T02:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000013', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-13T02:50:25.000' AS DateTime), CAST(N'2020-07-13T02:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000014', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-14T02:50:25.000' AS DateTime), CAST(N'2020-07-14T02:50:25.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000015', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-05-30T17:50:25.000' AS DateTime), CAST(N'2020-06-30T17:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000016', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-01T17:50:25.000' AS DateTime), CAST(N'2020-07-01T17:50:25.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000017', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-02T17:50:25.000' AS DateTime), CAST(N'2020-07-02T17:50:25.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000018', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-03T17:50:25.000' AS DateTime), CAST(N'2020-07-03T17:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000019', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-04T17:50:25.000' AS DateTime), CAST(N'2020-07-04T17:50:25.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000020', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-05T17:50:25.000' AS DateTime), CAST(N'2020-07-05T17:50:25.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000021', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-06T17:50:25.000' AS DateTime), CAST(N'2020-07-06T17:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000022', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-07T17:50:25.000' AS DateTime), CAST(N'2020-07-07T17:50:25.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000023', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-08T17:50:25.000' AS DateTime), CAST(N'2020-07-08T17:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000024', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-09T17:50:25.000' AS DateTime), CAST(N'2020-07-09T17:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000025', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-10T17:50:25.000' AS DateTime), CAST(N'2020-07-10T17:50:25.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000026', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-11T17:50:25.000' AS DateTime), CAST(N'2020-07-11T17:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000027', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-12T17:50:25.000' AS DateTime), CAST(N'2020-07-12T17:50:25.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000028', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-13T17:50:25.000' AS DateTime), CAST(N'2020-07-13T17:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000029', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-14T17:50:25.000' AS DateTime), CAST(N'2020-07-14T17:50:25.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000030', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-05-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000031', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000032', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000033', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000034', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000035', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000036', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000037', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000038', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000039', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000040', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000041', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000042', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000043', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000044', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000045', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-05-30T12:50:26.000' AS DateTime), CAST(N'2020-06-30T12:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000046', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-01T12:50:26.000' AS DateTime), CAST(N'2020-07-01T12:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000047', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-02T12:50:26.000' AS DateTime), CAST(N'2020-07-02T12:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000048', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-03T12:50:26.000' AS DateTime), CAST(N'2020-07-03T12:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000049', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-04T12:50:26.000' AS DateTime), CAST(N'2020-07-04T12:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000050', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-05T12:50:26.000' AS DateTime), CAST(N'2020-07-05T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000051', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-06T12:50:26.000' AS DateTime), CAST(N'2020-07-06T12:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000052', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-07T12:50:26.000' AS DateTime), CAST(N'2020-07-07T12:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000053', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-08T12:50:26.000' AS DateTime), CAST(N'2020-07-08T12:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000054', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-09T12:50:26.000' AS DateTime), CAST(N'2020-07-09T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000055', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-10T12:50:26.000' AS DateTime), CAST(N'2020-07-10T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000056', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-11T12:50:26.000' AS DateTime), CAST(N'2020-07-11T12:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000057', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-12T12:50:26.000' AS DateTime), CAST(N'2020-07-12T12:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000058', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-13T12:50:26.000' AS DateTime), CAST(N'2020-07-13T12:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000059', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-14T12:50:26.000' AS DateTime), CAST(N'2020-07-14T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000060', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-05-30T06:50:26.000' AS DateTime), CAST(N'2020-06-30T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000061', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-01T06:50:26.000' AS DateTime), CAST(N'2020-07-01T06:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000062', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-02T06:50:26.000' AS DateTime), CAST(N'2020-07-02T06:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000063', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-03T06:50:26.000' AS DateTime), CAST(N'2020-07-03T06:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000064', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-04T06:50:26.000' AS DateTime), CAST(N'2020-07-04T06:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000065', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-05T06:50:26.000' AS DateTime), CAST(N'2020-07-05T06:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000066', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-06T06:50:26.000' AS DateTime), CAST(N'2020-07-06T06:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000067', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-07T06:50:26.000' AS DateTime), CAST(N'2020-07-07T06:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000068', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-08T06:50:26.000' AS DateTime), CAST(N'2020-07-08T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000069', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-09T06:50:26.000' AS DateTime), CAST(N'2020-07-09T06:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000070', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-10T06:50:26.000' AS DateTime), CAST(N'2020-07-10T06:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000071', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-11T06:50:26.000' AS DateTime), CAST(N'2020-07-11T06:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000072', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-12T06:50:26.000' AS DateTime), CAST(N'2020-07-12T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000073', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-13T06:50:26.000' AS DateTime), CAST(N'2020-07-13T06:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000074', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-14T06:50:26.000' AS DateTime), CAST(N'2020-07-14T06:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000075', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-05-30T03:50:26.000' AS DateTime), CAST(N'2020-06-30T03:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000076', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-01T03:50:26.000' AS DateTime), CAST(N'2020-07-01T03:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000077', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-02T03:50:26.000' AS DateTime), CAST(N'2020-07-02T03:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000078', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-03T03:50:26.000' AS DateTime), CAST(N'2020-07-03T03:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000079', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-04T03:50:26.000' AS DateTime), CAST(N'2020-07-04T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 7, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000080', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-05T03:50:26.000' AS DateTime), CAST(N'2020-07-05T03:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000081', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-06T03:50:26.000' AS DateTime), CAST(N'2020-07-06T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000082', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-07T03:50:26.000' AS DateTime), CAST(N'2020-07-07T03:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000083', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-08T03:50:26.000' AS DateTime), CAST(N'2020-07-08T03:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000084', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-09T03:50:26.000' AS DateTime), CAST(N'2020-07-09T03:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000085', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-10T03:50:26.000' AS DateTime), CAST(N'2020-07-10T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000086', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-11T03:50:26.000' AS DateTime), CAST(N'2020-07-11T03:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000087', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-12T03:50:26.000' AS DateTime), CAST(N'2020-07-12T03:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000088', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-13T03:50:26.000' AS DateTime), CAST(N'2020-07-13T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000089', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-14T03:50:26.000' AS DateTime), CAST(N'2020-07-14T03:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000090', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-05-30T18:50:26.000' AS DateTime), CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000091', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-01T18:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000092', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-02T18:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000093', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-03T18:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000094', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-04T18:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000095', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-05T18:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000096', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-06T18:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000097', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-07T18:50:26.000' AS DateTime), CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000098', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-08T18:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000099', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-09T18:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000100', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-10T18:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000101', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-11T18:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000102', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-12T18:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000103', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-13T18:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000104', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-14T18:50:26.000' AS DateTime), CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000105', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-05-30T14:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000106', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-01T14:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000107', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-02T14:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000108', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-03T14:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000109', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-04T14:50:26.000' AS DateTime), CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000110', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-05T14:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000111', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-06T14:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 7, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000112', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-07T14:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000113', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-08T14:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000114', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-09T14:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000115', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-10T14:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000116', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-11T14:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000117', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-12T14:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000118', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-13T14:50:26.000' AS DateTime), CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000119', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-14T14:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000120', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-05-30T15:50:26.000' AS DateTime), CAST(N'2020-06-30T15:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000121', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-01T15:50:26.000' AS DateTime), CAST(N'2020-07-01T15:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000122', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-02T15:50:26.000' AS DateTime), CAST(N'2020-07-02T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000123', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-03T15:50:26.000' AS DateTime), CAST(N'2020-07-03T15:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000124', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-04T15:50:26.000' AS DateTime), CAST(N'2020-07-04T15:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000125', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-05T15:50:26.000' AS DateTime), CAST(N'2020-07-05T15:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000126', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-06T15:50:26.000' AS DateTime), CAST(N'2020-07-06T15:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000127', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-07T15:50:26.000' AS DateTime), CAST(N'2020-07-07T15:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000128', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-08T15:50:26.000' AS DateTime), CAST(N'2020-07-08T15:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000129', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-09T15:50:26.000' AS DateTime), CAST(N'2020-07-09T15:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000130', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-10T15:50:26.000' AS DateTime), CAST(N'2020-07-10T15:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000131', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-11T15:50:26.000' AS DateTime), CAST(N'2020-07-11T15:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000132', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-12T15:50:26.000' AS DateTime), CAST(N'2020-07-12T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000133', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-13T15:50:26.000' AS DateTime), CAST(N'2020-07-13T15:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000134', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-14T15:50:26.000' AS DateTime), CAST(N'2020-07-14T15:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000135', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-05-30T13:50:26.000' AS DateTime), CAST(N'2020-06-30T13:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000136', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-01T13:50:26.000' AS DateTime), CAST(N'2020-07-01T13:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000137', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-02T13:50:26.000' AS DateTime), CAST(N'2020-07-02T13:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000138', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-03T13:50:26.000' AS DateTime), CAST(N'2020-07-03T13:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000139', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-04T13:50:26.000' AS DateTime), CAST(N'2020-07-04T13:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000140', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-05T13:50:26.000' AS DateTime), CAST(N'2020-07-05T13:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000141', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-06T13:50:26.000' AS DateTime), CAST(N'2020-07-06T13:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000142', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-07T13:50:26.000' AS DateTime), CAST(N'2020-07-07T13:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000143', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-08T13:50:26.000' AS DateTime), CAST(N'2020-07-08T13:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000144', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-09T13:50:26.000' AS DateTime), CAST(N'2020-07-09T13:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000145', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-10T13:50:26.000' AS DateTime), CAST(N'2020-07-10T13:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000146', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-11T13:50:26.000' AS DateTime), CAST(N'2020-07-11T13:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000147', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-12T13:50:26.000' AS DateTime), CAST(N'2020-07-12T13:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000148', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-13T13:50:26.000' AS DateTime), CAST(N'2020-07-13T13:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000149', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-14T13:50:26.000' AS DateTime), CAST(N'2020-07-14T13:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000150', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-05-30T16:50:26.000' AS DateTime), CAST(N'2020-06-30T16:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000151', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-01T16:50:26.000' AS DateTime), CAST(N'2020-07-01T16:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000152', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-02T16:50:26.000' AS DateTime), CAST(N'2020-07-02T16:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000153', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-03T16:50:26.000' AS DateTime), CAST(N'2020-07-03T16:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000154', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-04T16:50:26.000' AS DateTime), CAST(N'2020-07-04T16:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000155', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-05T16:50:26.000' AS DateTime), CAST(N'2020-07-05T16:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000156', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-06T16:50:26.000' AS DateTime), CAST(N'2020-07-06T16:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000157', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-07T16:50:26.000' AS DateTime), CAST(N'2020-07-07T16:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000158', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-08T16:50:26.000' AS DateTime), CAST(N'2020-07-08T16:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000159', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-09T16:50:26.000' AS DateTime), CAST(N'2020-07-09T16:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000160', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-10T16:50:26.000' AS DateTime), CAST(N'2020-07-10T16:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000161', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-11T16:50:26.000' AS DateTime), CAST(N'2020-07-11T16:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000162', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-12T16:50:26.000' AS DateTime), CAST(N'2020-07-12T16:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000163', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-13T16:50:26.000' AS DateTime), CAST(N'2020-07-13T16:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000164', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-14T16:50:26.000' AS DateTime), CAST(N'2020-07-14T16:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000165', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-05-30T10:50:26.000' AS DateTime), CAST(N'2020-06-30T10:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000166', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-01T10:50:26.000' AS DateTime), CAST(N'2020-07-01T10:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000167', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-02T10:50:26.000' AS DateTime), CAST(N'2020-07-02T10:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000168', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-03T10:50:26.000' AS DateTime), CAST(N'2020-07-03T10:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000169', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-04T10:50:26.000' AS DateTime), CAST(N'2020-07-04T10:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000170', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-05T10:50:26.000' AS DateTime), CAST(N'2020-07-05T10:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000171', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-06T10:50:26.000' AS DateTime), CAST(N'2020-07-06T10:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000172', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-07T10:50:26.000' AS DateTime), CAST(N'2020-07-07T10:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000173', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-08T10:50:26.000' AS DateTime), CAST(N'2020-07-08T10:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000174', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-09T10:50:26.000' AS DateTime), CAST(N'2020-07-09T10:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000175', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-10T10:50:26.000' AS DateTime), CAST(N'2020-07-10T10:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 6, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000176', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-11T10:50:26.000' AS DateTime), CAST(N'2020-07-11T10:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000177', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-12T10:50:26.000' AS DateTime), CAST(N'2020-07-12T10:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000178', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-13T10:50:26.000' AS DateTime), CAST(N'2020-07-13T10:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000179', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-14T10:50:26.000' AS DateTime), CAST(N'2020-07-14T10:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000180', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-05-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000181', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000182', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000183', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000184', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000185', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000186', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000187', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000188', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000189', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000190', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000191', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000192', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000193', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000194', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000195', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-05-30T09:50:26.000' AS DateTime), CAST(N'2020-06-30T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000196', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-01T09:50:26.000' AS DateTime), CAST(N'2020-07-01T09:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000197', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-02T09:50:26.000' AS DateTime), CAST(N'2020-07-02T09:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000198', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-03T09:50:26.000' AS DateTime), CAST(N'2020-07-03T09:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000199', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-04T09:50:26.000' AS DateTime), CAST(N'2020-07-04T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000200', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-05T09:50:26.000' AS DateTime), CAST(N'2020-07-05T09:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000201', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-06T09:50:26.000' AS DateTime), CAST(N'2020-07-06T09:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000202', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-07T09:50:26.000' AS DateTime), CAST(N'2020-07-07T09:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000203', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-08T09:50:26.000' AS DateTime), CAST(N'2020-07-08T09:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000204', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-09T09:50:26.000' AS DateTime), CAST(N'2020-07-09T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000205', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-10T09:50:26.000' AS DateTime), CAST(N'2020-07-10T09:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 4, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000206', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-11T09:50:26.000' AS DateTime), CAST(N'2020-07-11T09:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000207', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-12T09:50:26.000' AS DateTime), CAST(N'2020-07-12T09:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000208', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-13T09:50:26.000' AS DateTime), CAST(N'2020-07-13T09:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000209', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-14T09:50:26.000' AS DateTime), CAST(N'2020-07-14T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000210', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-05-30T04:50:26.000' AS DateTime), CAST(N'2020-06-30T04:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000211', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-01T04:50:26.000' AS DateTime), CAST(N'2020-07-01T04:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000212', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-02T04:50:26.000' AS DateTime), CAST(N'2020-07-02T04:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000213', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-03T04:50:26.000' AS DateTime), CAST(N'2020-07-03T04:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000214', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-04T04:50:26.000' AS DateTime), CAST(N'2020-07-04T04:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000215', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-05T04:50:26.000' AS DateTime), CAST(N'2020-07-05T04:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000216', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-06T04:50:26.000' AS DateTime), CAST(N'2020-07-06T04:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000217', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-07T04:50:26.000' AS DateTime), CAST(N'2020-07-07T04:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000218', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-08T04:50:26.000' AS DateTime), CAST(N'2020-07-08T04:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000219', CAST(600.00 AS Numeric(8, 2)), CAST(N'2020-06-09T04:50:26.000' AS DateTime), CAST(N'2020-07-09T04:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000220', CAST(500.00 AS Numeric(8, 2)), CAST(N'2020-06-10T04:50:26.000' AS DateTime), CAST(N'2020-07-10T04:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000221', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-11T04:50:26.000' AS DateTime), CAST(N'2020-07-11T04:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000222', CAST(800.00 AS Numeric(8, 2)), CAST(N'2020-06-12T04:50:26.000' AS DateTime), CAST(N'2020-07-12T04:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000223', CAST(900.00 AS Numeric(8, 2)), CAST(N'2020-06-13T04:50:26.000' AS DateTime), CAST(N'2020-07-13T04:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (2, N'1000000224', CAST(700.00 AS Numeric(8, 2)), CAST(N'2020-06-14T04:50:26.000' AS DateTime), CAST(N'2020-07-14T04:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 8, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000000', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-05-30T02:50:25.000' AS DateTime), CAST(N'2020-06-30T02:50:25.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000001', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-01T02:50:25.000' AS DateTime), CAST(N'2020-07-01T02:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000002', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-02T02:50:25.000' AS DateTime), CAST(N'2020-07-02T02:50:25.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000003', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T02:50:25.000' AS DateTime), CAST(N'2020-07-03T02:50:25.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000004', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-04T02:50:25.000' AS DateTime), CAST(N'2020-07-04T02:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000005', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-05T02:50:25.000' AS DateTime), CAST(N'2020-07-05T02:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000006', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-06T02:50:25.000' AS DateTime), CAST(N'2020-07-06T02:50:25.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000007', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-07T02:50:25.000' AS DateTime), CAST(N'2020-07-07T02:50:25.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000008', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-08T02:50:25.000' AS DateTime), CAST(N'2020-07-08T02:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000009', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-09T02:50:25.000' AS DateTime), CAST(N'2020-07-09T02:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 118, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000010', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-10T02:50:25.000' AS DateTime), CAST(N'2020-07-10T02:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000011', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-11T02:50:25.000' AS DateTime), CAST(N'2020-07-11T02:50:25.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000012', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-12T02:50:25.000' AS DateTime), CAST(N'2020-07-12T02:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000013', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-13T02:50:25.000' AS DateTime), CAST(N'2020-07-13T02:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000014', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-14T02:50:25.000' AS DateTime), CAST(N'2020-07-14T02:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000015', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-05-30T17:50:25.000' AS DateTime), CAST(N'2020-06-30T17:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000016', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-01T17:50:25.000' AS DateTime), CAST(N'2020-07-01T17:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000017', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-02T17:50:25.000' AS DateTime), CAST(N'2020-07-02T17:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000018', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-03T17:50:25.000' AS DateTime), CAST(N'2020-07-03T17:50:25.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000019', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-04T17:50:25.000' AS DateTime), CAST(N'2020-07-04T17:50:25.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000020', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T17:50:25.000' AS DateTime), CAST(N'2020-07-05T17:50:25.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000021', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-06T17:50:25.000' AS DateTime), CAST(N'2020-07-06T17:50:25.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000022', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-07T17:50:25.000' AS DateTime), CAST(N'2020-07-07T17:50:25.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000023', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-08T17:50:25.000' AS DateTime), CAST(N'2020-07-08T17:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000024', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-09T17:50:25.000' AS DateTime), CAST(N'2020-07-09T17:50:25.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000025', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-10T17:50:25.000' AS DateTime), CAST(N'2020-07-10T17:50:25.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000026', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-11T17:50:25.000' AS DateTime), CAST(N'2020-07-11T17:50:25.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000027', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-12T17:50:25.000' AS DateTime), CAST(N'2020-07-12T17:50:25.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000028', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-13T17:50:25.000' AS DateTime), CAST(N'2020-07-13T17:50:25.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000029', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-14T17:50:25.000' AS DateTime), CAST(N'2020-07-14T17:50:25.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000030', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-05-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 118, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000031', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000032', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000033', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000034', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000035', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000036', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000037', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000038', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000039', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000040', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000041', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000042', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000043', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000044', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000045', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-05-30T12:50:26.000' AS DateTime), CAST(N'2020-06-30T12:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000046', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-01T12:50:26.000' AS DateTime), CAST(N'2020-07-01T12:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000047', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-02T12:50:26.000' AS DateTime), CAST(N'2020-07-02T12:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000048', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-03T12:50:26.000' AS DateTime), CAST(N'2020-07-03T12:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000049', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-04T12:50:26.000' AS DateTime), CAST(N'2020-07-04T12:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000050', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-05T12:50:26.000' AS DateTime), CAST(N'2020-07-05T12:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000051', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-06T12:50:26.000' AS DateTime), CAST(N'2020-07-06T12:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000052', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-07T12:50:26.000' AS DateTime), CAST(N'2020-07-07T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 119, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000053', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-08T12:50:26.000' AS DateTime), CAST(N'2020-07-08T12:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000054', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-09T12:50:26.000' AS DateTime), CAST(N'2020-07-09T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000055', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-10T12:50:26.000' AS DateTime), CAST(N'2020-07-10T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000056', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-11T12:50:26.000' AS DateTime), CAST(N'2020-07-11T12:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000057', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-12T12:50:26.000' AS DateTime), CAST(N'2020-07-12T12:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000058', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-13T12:50:26.000' AS DateTime), CAST(N'2020-07-13T12:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000059', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-14T12:50:26.000' AS DateTime), CAST(N'2020-07-14T12:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000060', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-05-30T06:50:26.000' AS DateTime), CAST(N'2020-06-30T06:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000061', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-01T06:50:26.000' AS DateTime), CAST(N'2020-07-01T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000062', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-02T06:50:26.000' AS DateTime), CAST(N'2020-07-02T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000063', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T06:50:26.000' AS DateTime), CAST(N'2020-07-03T06:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000064', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-04T06:50:26.000' AS DateTime), CAST(N'2020-07-04T06:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000065', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-05T06:50:26.000' AS DateTime), CAST(N'2020-07-05T06:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000066', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-06T06:50:26.000' AS DateTime), CAST(N'2020-07-06T06:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000067', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-07T06:50:26.000' AS DateTime), CAST(N'2020-07-07T06:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000068', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-08T06:50:26.000' AS DateTime), CAST(N'2020-07-08T06:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000069', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-09T06:50:26.000' AS DateTime), CAST(N'2020-07-09T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000070', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-10T06:50:26.000' AS DateTime), CAST(N'2020-07-10T06:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000071', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-11T06:50:26.000' AS DateTime), CAST(N'2020-07-11T06:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000072', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-12T06:50:26.000' AS DateTime), CAST(N'2020-07-12T06:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000073', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-13T06:50:26.000' AS DateTime), CAST(N'2020-07-13T06:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000074', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-14T06:50:26.000' AS DateTime), CAST(N'2020-07-14T06:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000075', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-05-30T03:50:26.000' AS DateTime), CAST(N'2020-06-30T03:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000076', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-01T03:50:26.000' AS DateTime), CAST(N'2020-07-01T03:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000077', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-02T03:50:26.000' AS DateTime), CAST(N'2020-07-02T03:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000078', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-03T03:50:26.000' AS DateTime), CAST(N'2020-07-03T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000079', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-04T03:50:26.000' AS DateTime), CAST(N'2020-07-04T03:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000080', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-05T03:50:26.000' AS DateTime), CAST(N'2020-07-05T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000081', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-06T03:50:26.000' AS DateTime), CAST(N'2020-07-06T03:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000082', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-07T03:50:26.000' AS DateTime), CAST(N'2020-07-07T03:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000083', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-08T03:50:26.000' AS DateTime), CAST(N'2020-07-08T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000084', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-09T03:50:26.000' AS DateTime), CAST(N'2020-07-09T03:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000085', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-10T03:50:26.000' AS DateTime), CAST(N'2020-07-10T03:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000086', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-11T03:50:26.000' AS DateTime), CAST(N'2020-07-11T03:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000087', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-12T03:50:26.000' AS DateTime), CAST(N'2020-07-12T03:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000088', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-13T03:50:26.000' AS DateTime), CAST(N'2020-07-13T03:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000089', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-14T03:50:26.000' AS DateTime), CAST(N'2020-07-14T03:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000090', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-05-30T18:50:26.000' AS DateTime), CAST(N'2020-06-30T18:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000091', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-01T18:50:26.000' AS DateTime), CAST(N'2020-07-01T18:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000092', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-02T18:50:26.000' AS DateTime), CAST(N'2020-07-02T18:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000093', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T18:50:26.000' AS DateTime), CAST(N'2020-07-03T18:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000094', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-04T18:50:26.000' AS DateTime), CAST(N'2020-07-04T18:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000095', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T18:50:26.000' AS DateTime), CAST(N'2020-07-05T18:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000096', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-06T18:50:26.000' AS DateTime), CAST(N'2020-07-06T18:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000097', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-07T18:50:26.000' AS DateTime), CAST(N'2020-07-07T18:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000098', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-08T18:50:26.000' AS DateTime), CAST(N'2020-07-08T18:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000099', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-09T18:50:26.000' AS DateTime), CAST(N'2020-07-09T18:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000100', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-10T18:50:26.000' AS DateTime), CAST(N'2020-07-10T18:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000101', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-11T18:50:26.000' AS DateTime), CAST(N'2020-07-11T18:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000102', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-12T18:50:26.000' AS DateTime), CAST(N'2020-07-12T18:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000103', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-13T18:50:26.000' AS DateTime), CAST(N'2020-07-13T18:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000104', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-14T18:50:26.000' AS DateTime), CAST(N'2020-07-14T18:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 119, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000105', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-05-30T14:50:26.000' AS DateTime), CAST(N'2020-06-30T14:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000106', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-01T14:50:26.000' AS DateTime), CAST(N'2020-07-01T14:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000107', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-02T14:50:26.000' AS DateTime), CAST(N'2020-07-02T14:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000108', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-03T14:50:26.000' AS DateTime), CAST(N'2020-07-03T14:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000109', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-04T14:50:26.000' AS DateTime), CAST(N'2020-07-04T14:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000110', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T14:50:26.000' AS DateTime), CAST(N'2020-07-05T14:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000111', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-06T14:50:26.000' AS DateTime), CAST(N'2020-07-06T14:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000112', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-07T14:50:26.000' AS DateTime), CAST(N'2020-07-07T14:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000113', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-08T14:50:26.000' AS DateTime), CAST(N'2020-07-08T14:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000114', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-09T14:50:26.000' AS DateTime), CAST(N'2020-07-09T14:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000115', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-10T14:50:26.000' AS DateTime), CAST(N'2020-07-10T14:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000116', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-11T14:50:26.000' AS DateTime), CAST(N'2020-07-11T14:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000117', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-12T14:50:26.000' AS DateTime), CAST(N'2020-07-12T14:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000118', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-13T14:50:26.000' AS DateTime), CAST(N'2020-07-13T14:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000119', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-14T14:50:26.000' AS DateTime), CAST(N'2020-07-14T14:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000120', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-05-30T15:50:26.000' AS DateTime), CAST(N'2020-06-30T15:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000121', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-01T15:50:26.000' AS DateTime), CAST(N'2020-07-01T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000122', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-02T15:50:26.000' AS DateTime), CAST(N'2020-07-02T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000123', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T15:50:26.000' AS DateTime), CAST(N'2020-07-03T15:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000124', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-04T15:50:26.000' AS DateTime), CAST(N'2020-07-04T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000125', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-05T15:50:26.000' AS DateTime), CAST(N'2020-07-05T15:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000126', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-06T15:50:26.000' AS DateTime), CAST(N'2020-07-06T15:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000127', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-07T15:50:26.000' AS DateTime), CAST(N'2020-07-07T15:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000128', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-08T15:50:26.000' AS DateTime), CAST(N'2020-07-08T15:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000129', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-09T15:50:26.000' AS DateTime), CAST(N'2020-07-09T15:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000130', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-10T15:50:26.000' AS DateTime), CAST(N'2020-07-10T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000131', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-11T15:50:26.000' AS DateTime), CAST(N'2020-07-11T15:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000132', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-12T15:50:26.000' AS DateTime), CAST(N'2020-07-12T15:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000133', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-13T15:50:26.000' AS DateTime), CAST(N'2020-07-13T15:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000134', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-14T15:50:26.000' AS DateTime), CAST(N'2020-07-14T15:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000135', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-05-30T13:50:26.000' AS DateTime), CAST(N'2020-06-30T13:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000136', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-01T13:50:26.000' AS DateTime), CAST(N'2020-07-01T13:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000137', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-02T13:50:26.000' AS DateTime), CAST(N'2020-07-02T13:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000138', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-03T13:50:26.000' AS DateTime), CAST(N'2020-07-03T13:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000139', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-04T13:50:26.000' AS DateTime), CAST(N'2020-07-04T13:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000140', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T13:50:26.000' AS DateTime), CAST(N'2020-07-05T13:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000141', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-06T13:50:26.000' AS DateTime), CAST(N'2020-07-06T13:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000142', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-07T13:50:26.000' AS DateTime), CAST(N'2020-07-07T13:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000143', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-08T13:50:26.000' AS DateTime), CAST(N'2020-07-08T13:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000144', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-09T13:50:26.000' AS DateTime), CAST(N'2020-07-09T13:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000145', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-10T13:50:26.000' AS DateTime), CAST(N'2020-07-10T13:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000146', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-11T13:50:26.000' AS DateTime), CAST(N'2020-07-11T13:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000147', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-12T13:50:26.000' AS DateTime), CAST(N'2020-07-12T13:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000148', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-13T13:50:26.000' AS DateTime), CAST(N'2020-07-13T13:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000149', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-14T13:50:26.000' AS DateTime), CAST(N'2020-07-14T13:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000150', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-05-30T16:50:26.000' AS DateTime), CAST(N'2020-06-30T16:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000151', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-01T16:50:26.000' AS DateTime), CAST(N'2020-07-01T16:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000152', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-02T16:50:26.000' AS DateTime), CAST(N'2020-07-02T16:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000153', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T16:50:26.000' AS DateTime), CAST(N'2020-07-03T16:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000154', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-04T16:50:26.000' AS DateTime), CAST(N'2020-07-04T16:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000155', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T16:50:26.000' AS DateTime), CAST(N'2020-07-05T16:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000156', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-06T16:50:26.000' AS DateTime), CAST(N'2020-07-06T16:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000157', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-07T16:50:26.000' AS DateTime), CAST(N'2020-07-07T16:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000158', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-08T16:50:26.000' AS DateTime), CAST(N'2020-07-08T16:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000159', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-09T16:50:26.000' AS DateTime), CAST(N'2020-07-09T16:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000160', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-10T16:50:26.000' AS DateTime), CAST(N'2020-07-10T16:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000161', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-11T16:50:26.000' AS DateTime), CAST(N'2020-07-11T16:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000162', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-12T16:50:26.000' AS DateTime), CAST(N'2020-07-12T16:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000163', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-13T16:50:26.000' AS DateTime), CAST(N'2020-07-13T16:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000164', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-14T16:50:26.000' AS DateTime), CAST(N'2020-07-14T16:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000165', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-05-30T10:50:26.000' AS DateTime), CAST(N'2020-06-30T10:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000166', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-01T10:50:26.000' AS DateTime), CAST(N'2020-07-01T10:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000167', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-02T10:50:26.000' AS DateTime), CAST(N'2020-07-02T10:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000168', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T10:50:26.000' AS DateTime), CAST(N'2020-07-03T10:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000169', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-04T10:50:26.000' AS DateTime), CAST(N'2020-07-04T10:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000170', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-05T10:50:26.000' AS DateTime), CAST(N'2020-07-05T10:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000171', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-06T10:50:26.000' AS DateTime), CAST(N'2020-07-06T10:50:26.000' AS DateTime), CAST(1.00 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000172', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-07T10:50:26.000' AS DateTime), CAST(N'2020-07-07T10:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000173', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-08T10:50:26.000' AS DateTime), CAST(N'2020-07-08T10:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000174', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-09T10:50:26.000' AS DateTime), CAST(N'2020-07-09T10:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000175', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-10T10:50:26.000' AS DateTime), CAST(N'2020-07-10T10:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000176', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-11T10:50:26.000' AS DateTime), CAST(N'2020-07-11T10:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000177', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-12T10:50:26.000' AS DateTime), CAST(N'2020-07-12T10:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000178', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-13T10:50:26.000' AS DateTime), CAST(N'2020-07-13T10:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000179', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-14T10:50:26.000' AS DateTime), CAST(N'2020-07-14T10:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000180', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-05-30T01:50:26.000' AS DateTime), CAST(N'2020-06-30T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000181', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-01T01:50:26.000' AS DateTime), CAST(N'2020-07-01T01:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000182', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-02T01:50:26.000' AS DateTime), CAST(N'2020-07-02T01:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000183', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-03T01:50:26.000' AS DateTime), CAST(N'2020-07-03T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000184', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-04T01:50:26.000' AS DateTime), CAST(N'2020-07-04T01:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000185', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T01:50:26.000' AS DateTime), CAST(N'2020-07-05T01:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000186', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-06T01:50:26.000' AS DateTime), CAST(N'2020-07-06T01:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000187', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-07T01:50:26.000' AS DateTime), CAST(N'2020-07-07T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000188', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-08T01:50:26.000' AS DateTime), CAST(N'2020-07-08T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000189', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-09T01:50:26.000' AS DateTime), CAST(N'2020-07-09T01:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000190', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-10T01:50:26.000' AS DateTime), CAST(N'2020-07-10T01:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000191', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-11T01:50:26.000' AS DateTime), CAST(N'2020-07-11T01:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000192', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-12T01:50:26.000' AS DateTime), CAST(N'2020-07-12T01:50:26.000' AS DateTime), CAST(0.30 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000193', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-13T01:50:26.000' AS DateTime), CAST(N'2020-07-13T01:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000194', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-14T01:50:26.000' AS DateTime), CAST(N'2020-07-14T01:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000195', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-05-30T09:50:26.000' AS DateTime), CAST(N'2020-06-30T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000196', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-01T09:50:26.000' AS DateTime), CAST(N'2020-07-01T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000197', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-02T09:50:26.000' AS DateTime), CAST(N'2020-07-02T09:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000198', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-03T09:50:26.000' AS DateTime), CAST(N'2020-07-03T09:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000199', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-04T09:50:26.000' AS DateTime), CAST(N'2020-07-04T09:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000200', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-05T09:50:26.000' AS DateTime), CAST(N'2020-07-05T09:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000201', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-06T09:50:26.000' AS DateTime), CAST(N'2020-07-06T09:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000202', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-07T09:50:26.000' AS DateTime), CAST(N'2020-07-07T09:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000203', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-08T09:50:26.000' AS DateTime), CAST(N'2020-07-08T09:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000204', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-09T09:50:26.000' AS DateTime), CAST(N'2020-07-09T09:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000205', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-10T09:50:26.000' AS DateTime), CAST(N'2020-07-10T09:50:26.000' AS DateTime), CAST(0.50 AS Numeric(4, 2)), 113, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000206', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-11T09:50:26.000' AS DateTime), CAST(N'2020-07-11T09:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000207', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-12T09:50:26.000' AS DateTime), CAST(N'2020-07-12T09:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000208', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-13T09:50:26.000' AS DateTime), CAST(N'2020-07-13T09:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000209', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-14T09:50:26.000' AS DateTime), CAST(N'2020-07-14T09:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000210', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-05-30T04:50:26.000' AS DateTime), CAST(N'2020-06-30T04:50:26.000' AS DateTime), CAST(0.40 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000211', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-01T04:50:26.000' AS DateTime), CAST(N'2020-07-01T04:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000212', CAST(300.00 AS Numeric(8, 2)), CAST(N'2020-06-02T04:50:26.000' AS DateTime), CAST(N'2020-07-02T04:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000213', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-03T04:50:26.000' AS DateTime), CAST(N'2020-07-03T04:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000214', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-04T04:50:26.000' AS DateTime), CAST(N'2020-07-04T04:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000215', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-05T04:50:26.000' AS DateTime), CAST(N'2020-07-05T04:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000216', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-06T04:50:26.000' AS DateTime), CAST(N'2020-07-06T04:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000217', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-07T04:50:26.000' AS DateTime), CAST(N'2020-07-07T04:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000218', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-08T04:50:26.000' AS DateTime), CAST(N'2020-07-08T04:50:26.000' AS DateTime), CAST(0.10 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000219', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-09T04:50:26.000' AS DateTime), CAST(N'2020-07-09T04:50:26.000' AS DateTime), CAST(0.80 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000220', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-10T04:50:26.000' AS DateTime), CAST(N'2020-07-10T04:50:26.000' AS DateTime), CAST(0.20 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000221', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-11T04:50:26.000' AS DateTime), CAST(N'2020-07-11T04:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000222', CAST(400.00 AS Numeric(8, 2)), CAST(N'2020-06-12T04:50:26.000' AS DateTime), CAST(N'2020-07-12T04:50:26.000' AS DateTime), CAST(0.70 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000223', CAST(200.00 AS Numeric(8, 2)), CAST(N'2020-06-13T04:50:26.000' AS DateTime), CAST(N'2020-07-13T04:50:26.000' AS DateTime), CAST(0.90 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
INSERT [dbo].[ticketType] ([cabinId], [executiveFlightId], [sellingPrice], [effectiveStartTime], [effectiveEndTime], [discount], [remainingTickets], [luggageAllowance], [luggageNumber], [mealStatus], [rules]) VALUES (3, N'1000000224', CAST(100.00 AS Numeric(8, 2)), CAST(N'2020-06-14T04:50:26.000' AS DateTime), CAST(N'2020-07-14T04:50:26.000' AS DateTime), CAST(0.60 AS Numeric(4, 2)), 120, 1, 30, N'无', N'起飞前7天（含）前 自愿退票手续费率:20% 自愿变更手续费率:10% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30% 起飞前7天（不含）至48小时（含）之间 自愿退票手续费率:40% 自愿变更手续费率:30%')
GO
SET IDENTITY_INSERT [dbo].[users] ON 
GO
INSERT [dbo].[users] ([userId], [loginId], [password], [userName], [userSex], [userAge], [integral]) VALUES (2, N'13639023313', N'200217', N'大白', N'男', 20, 140)
GO
SET IDENTITY_INSERT [dbo].[users] OFF
GO
/****** Object:  Index [PK_ADMINISTRATOR]    Script Date: 2020/6/27 19:54:19 ******/
ALTER TABLE [dbo].[administrator] ADD  CONSTRAINT [PK_ADMINISTRATOR] PRIMARY KEY NONCLUSTERED 
(
	[adminId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_AIRPORT]    Script Date: 2020/6/27 19:54:19 ******/
ALTER TABLE [dbo].[airport] ADD  CONSTRAINT [PK_AIRPORT] PRIMARY KEY NONCLUSTERED 
(
	[airportId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [airportComposition_FK]    Script Date: 2020/6/27 19:54:19 ******/
CREATE NONCLUSTERED INDEX [airportComposition_FK] ON [dbo].[airport]
(
	[cityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [binding_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [binding_FK] ON [dbo].[binding]
(
	[userId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [binding2_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [binding2_FK] ON [dbo].[binding]
(
	[passengerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_CABIN]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[cabin] ADD  CONSTRAINT [PK_CABIN] PRIMARY KEY NONCLUSTERED 
(
	[cabinId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_CITY]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[city] ADD  CONSTRAINT [PK_CITY] PRIMARY KEY NONCLUSTERED 
(
	[cityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [辖属_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [辖属_FK] ON [dbo].[city]
(
	[provinceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [PK_EXECUTIVEFLIGHT]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[executiveFlight] ADD  CONSTRAINT [PK_EXECUTIVEFLIGHT] PRIMARY KEY NONCLUSTERED 
(
	[executiveFlightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [executiveFlightComposition_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [executiveFlightComposition_FK] ON [dbo].[executiveFlight]
(
	[flightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [PK_FLIGHT]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[flight] ADD  CONSTRAINT [PK_FLIGHT] PRIMARY KEY NONCLUSTERED 
(
	[flightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [modelComposition_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [modelComposition_FK] ON [dbo].[flight]
(
	[modelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [to_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [to_FK] ON [dbo].[flight]
(
	[terminalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [出发地_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [出发地_FK] ON [dbo].[flight]
(
	[ter_terminalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_LUGGAGE]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[luggage] ADD  CONSTRAINT [PK_LUGGAGE] PRIMARY KEY NONCLUSTERED 
(
	[luggageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [luggageTransportation_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [luggageTransportation_FK] ON [dbo].[luggage]
(
	[ticketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [PK_MODEL]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[model] ADD  CONSTRAINT [PK_MODEL] PRIMARY KEY NONCLUSTERED 
(
	[modelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_ORDERS]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[orders] ADD  CONSTRAINT [PK_ORDERS] PRIMARY KEY NONCLUSTERED 
(
	[orderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [booking_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [booking_FK] ON [dbo].[orders]
(
	[userId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [PK_PASSENGER]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[passenger] ADD  CONSTRAINT [PK_PASSENGER] PRIMARY KEY NONCLUSTERED 
(
	[passengerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_PROVINCE]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[province] ADD  CONSTRAINT [PK_PROVINCE] PRIMARY KEY NONCLUSTERED 
(
	[provinceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_SEATINGCHART]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[seatingChart] ADD  CONSTRAINT [PK_SEATINGCHART] PRIMARY KEY NONCLUSTERED 
(
	[seatId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [cabins_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [cabins_FK] ON [dbo].[seatingChart]
(
	[cabinId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [seats_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [seats_FK] ON [dbo].[seatingChart]
(
	[modelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [seatSelection_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [seatSelection_FK] ON [dbo].[seatSelection]
(
	[seatId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [seatSelection2_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [seatSelection2_FK] ON [dbo].[seatSelection]
(
	[executiveFlightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [seatSelection3_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [seatSelection3_FK] ON [dbo].[seatSelection]
(
	[ticketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_TERMINAL]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[terminal] ADD  CONSTRAINT [PK_TERMINAL] PRIMARY KEY NONCLUSTERED 
(
	[terminalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [terminalComposition_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [terminalComposition_FK] ON [dbo].[terminal]
(
	[airportId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_TICKET]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[ticket] ADD  CONSTRAINT [PK_TICKET] PRIMARY KEY NONCLUSTERED 
(
	[ticketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [orderComposition_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [orderComposition_FK] ON [dbo].[ticket]
(
	[orderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [passengers_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [passengers_FK] ON [dbo].[ticket]
(
	[passengerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [speciesComposition_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [speciesComposition_FK] ON [dbo].[ticket]
(
	[cabinId] ASC,
	[tic_executiveFlightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ticketComposition1_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [ticketComposition1_FK] ON [dbo].[ticketType]
(
	[executiveFlightId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [ticketComposition2_FK]    Script Date: 2020/6/27 19:54:20 ******/
CREATE NONCLUSTERED INDEX [ticketComposition2_FK] ON [dbo].[ticketType]
(
	[cabinId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_USERS]    Script Date: 2020/6/27 19:54:20 ******/
ALTER TABLE [dbo].[users] ADD  CONSTRAINT [PK_USERS] PRIMARY KEY NONCLUSTERED 
(
	[userId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[passenger] ADD  CONSTRAINT [DF_CREDITSTATUS]  DEFAULT ('正常') FOR [creditStatus]
GO
ALTER TABLE [dbo].[ticket] ADD  DEFAULT ((50)) FOR [airportConstructionCost]
GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((18)) FOR [userAge]
GO
ALTER TABLE [dbo].[users] ADD  CONSTRAINT [DF_users_integral]  DEFAULT ((0)) FOR [integral]
GO
ALTER TABLE [dbo].[airport]  WITH CHECK ADD  CONSTRAINT [FK_AIRPORT_AIRPORTCO_CITY] FOREIGN KEY([cityId])
REFERENCES [dbo].[city] ([cityId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[airport] CHECK CONSTRAINT [FK_AIRPORT_AIRPORTCO_CITY]
GO
ALTER TABLE [dbo].[binding]  WITH CHECK ADD  CONSTRAINT [FK_BINDING_BINDING_USERS] FOREIGN KEY([userId])
REFERENCES [dbo].[users] ([userId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[binding] CHECK CONSTRAINT [FK_BINDING_BINDING_USERS]
GO
ALTER TABLE [dbo].[binding]  WITH CHECK ADD  CONSTRAINT [FK_BINDING_BINDING2_PASSENGE] FOREIGN KEY([passengerId])
REFERENCES [dbo].[passenger] ([passengerId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[binding] CHECK CONSTRAINT [FK_BINDING_BINDING2_PASSENGE]
GO
ALTER TABLE [dbo].[city]  WITH CHECK ADD  CONSTRAINT [FK_CITY_BELONGTO_PROVINCE] FOREIGN KEY([provinceId])
REFERENCES [dbo].[province] ([provinceId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[city] CHECK CONSTRAINT [FK_CITY_BELONGTO_PROVINCE]
GO
ALTER TABLE [dbo].[executiveFlight]  WITH CHECK ADD  CONSTRAINT [FK_EXECUTIV_EXECUTIVE_FLIGHT] FOREIGN KEY([flightId])
REFERENCES [dbo].[flight] ([flightId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[executiveFlight] CHECK CONSTRAINT [FK_EXECUTIV_EXECUTIVE_FLIGHT]
GO
ALTER TABLE [dbo].[flight]  WITH CHECK ADD  CONSTRAINT [FK_FLIGHT_FROM_TERMINAL] FOREIGN KEY([ter_terminalId])
REFERENCES [dbo].[terminal] ([terminalId])
GO
ALTER TABLE [dbo].[flight] CHECK CONSTRAINT [FK_FLIGHT_FROM_TERMINAL]
GO
ALTER TABLE [dbo].[flight]  WITH CHECK ADD  CONSTRAINT [FK_FLIGHT_MODELCOMP_MODEL] FOREIGN KEY([modelId])
REFERENCES [dbo].[model] ([modelId])
GO
ALTER TABLE [dbo].[flight] CHECK CONSTRAINT [FK_FLIGHT_MODELCOMP_MODEL]
GO
ALTER TABLE [dbo].[flight]  WITH CHECK ADD  CONSTRAINT [FK_FLIGHT_TO_TERMINAL] FOREIGN KEY([terminalId])
REFERENCES [dbo].[terminal] ([terminalId])
GO
ALTER TABLE [dbo].[flight] CHECK CONSTRAINT [FK_FLIGHT_TO_TERMINAL]
GO
ALTER TABLE [dbo].[luggage]  WITH CHECK ADD  CONSTRAINT [FK_LUGGAGE_LUGGAGETR_TICKET] FOREIGN KEY([ticketId])
REFERENCES [dbo].[ticket] ([ticketId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[luggage] CHECK CONSTRAINT [FK_LUGGAGE_LUGGAGETR_TICKET]
GO
ALTER TABLE [dbo].[orders]  WITH CHECK ADD  CONSTRAINT [FK_ORDERS_BOOKING_USERS] FOREIGN KEY([userId])
REFERENCES [dbo].[users] ([userId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[orders] CHECK CONSTRAINT [FK_ORDERS_BOOKING_USERS]
GO
ALTER TABLE [dbo].[seatingChart]  WITH CHECK ADD  CONSTRAINT [FK_SEATINGC_CABINS_CABIN] FOREIGN KEY([cabinId])
REFERENCES [dbo].[cabin] ([cabinId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[seatingChart] CHECK CONSTRAINT [FK_SEATINGC_CABINS_CABIN]
GO
ALTER TABLE [dbo].[seatingChart]  WITH CHECK ADD  CONSTRAINT [FK_SEATINGC_SEATS_MODEL] FOREIGN KEY([modelId])
REFERENCES [dbo].[model] ([modelId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[seatingChart] CHECK CONSTRAINT [FK_SEATINGC_SEATS_MODEL]
GO
ALTER TABLE [dbo].[seatSelection]  WITH CHECK ADD  CONSTRAINT [FK_SEATSELE_SEATSELEC_EXECUTIV] FOREIGN KEY([executiveFlightId])
REFERENCES [dbo].[executiveFlight] ([executiveFlightId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[seatSelection] CHECK CONSTRAINT [FK_SEATSELE_SEATSELEC_EXECUTIV]
GO
ALTER TABLE [dbo].[seatSelection]  WITH CHECK ADD  CONSTRAINT [FK_SEATSELE_SEATSELEC_SEATINGC] FOREIGN KEY([seatId])
REFERENCES [dbo].[seatingChart] ([seatId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[seatSelection] CHECK CONSTRAINT [FK_SEATSELE_SEATSELEC_SEATINGC]
GO
ALTER TABLE [dbo].[seatSelection]  WITH CHECK ADD  CONSTRAINT [FK_SEATSELE_SEATSELEC_TICKET] FOREIGN KEY([ticketId])
REFERENCES [dbo].[ticket] ([ticketId])
GO
ALTER TABLE [dbo].[seatSelection] CHECK CONSTRAINT [FK_SEATSELE_SEATSELEC_TICKET]
GO
ALTER TABLE [dbo].[terminal]  WITH CHECK ADD  CONSTRAINT [FK_TERMINAL_TERMINALC_AIRPORT] FOREIGN KEY([airportId])
REFERENCES [dbo].[airport] ([airportId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[terminal] CHECK CONSTRAINT [FK_TERMINAL_TERMINALC_AIRPORT]
GO
ALTER TABLE [dbo].[ticket]  WITH CHECK ADD  CONSTRAINT [FK_TICKET_ORDERCOMP_ORDERS] FOREIGN KEY([orderId])
REFERENCES [dbo].[orders] ([orderId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ticket] CHECK CONSTRAINT [FK_TICKET_ORDERCOMP_ORDERS]
GO
ALTER TABLE [dbo].[ticket]  WITH CHECK ADD  CONSTRAINT [FK_TICKET_PASSENGER_PASSENGE] FOREIGN KEY([passengerId])
REFERENCES [dbo].[passenger] ([passengerId])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[ticket] CHECK CONSTRAINT [FK_TICKET_PASSENGER_PASSENGE]
GO
ALTER TABLE [dbo].[ticket]  WITH CHECK ADD  CONSTRAINT [FK_TICKET_SPECIESCO_TICKETTY] FOREIGN KEY([cabinId], [tic_executiveFlightId])
REFERENCES [dbo].[ticketType] ([cabinId], [executiveFlightId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ticket] CHECK CONSTRAINT [FK_TICKET_SPECIESCO_TICKETTY]
GO
ALTER TABLE [dbo].[ticketType]  WITH CHECK ADD  CONSTRAINT [FK_TICKETTY_TICKETCOM_CABIN] FOREIGN KEY([cabinId])
REFERENCES [dbo].[cabin] ([cabinId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ticketType] CHECK CONSTRAINT [FK_TICKETTY_TICKETCOM_CABIN]
GO
ALTER TABLE [dbo].[ticketType]  WITH CHECK ADD  CONSTRAINT [FK_TICKETTY_TICKETCOM_EXECUTIV] FOREIGN KEY([executiveFlightId])
REFERENCES [dbo].[executiveFlight] ([executiveFlightId])
GO
ALTER TABLE [dbo].[ticketType] CHECK CONSTRAINT [FK_TICKETTY_TICKETCOM_EXECUTIV]
GO
ALTER TABLE [dbo].[orders]  WITH CHECK ADD  CONSTRAINT [CKC_ORDERSTATUSX_ORDERS] CHECK  (([orderStatusx] IS NULL OR [orderStatusx]>='0'))
GO
ALTER TABLE [dbo].[orders] CHECK CONSTRAINT [CKC_ORDERSTATUSX_ORDERS]
GO
ALTER TABLE [dbo].[orders]  WITH CHECK ADD  CONSTRAINT [CKC_TOTALCOST_ORDERS] CHECK  (([totalCost] IS NULL OR [totalCost]>=(0)))
GO
ALTER TABLE [dbo].[orders] CHECK CONSTRAINT [CKC_TOTALCOST_ORDERS]
GO
ALTER TABLE [dbo].[passenger]  WITH CHECK ADD  CONSTRAINT [CKC_PASSENGERSEX_PASSENGE] CHECK  (([passengerSex] IS NULL OR ([passengerSex]='女' OR [passengerSex]='男')))
GO
ALTER TABLE [dbo].[passenger] CHECK CONSTRAINT [CKC_PASSENGERSEX_PASSENGE]
GO
ALTER TABLE [dbo].[ticket]  WITH CHECK ADD  CONSTRAINT [CKC_AIRPORTCONSTRUCTI_TICKET] CHECK  (([airportConstructionCost] IS NULL OR [airportConstructionCost]>=(0)))
GO
ALTER TABLE [dbo].[ticket] CHECK CONSTRAINT [CKC_AIRPORTCONSTRUCTI_TICKET]
GO
ALTER TABLE [dbo].[ticket]  WITH CHECK ADD  CONSTRAINT [CKC_INSURANCECOST_TICKET] CHECK  (([insuranceCost] IS NULL OR [insuranceCost]>=(0)))
GO
ALTER TABLE [dbo].[ticket] CHECK CONSTRAINT [CKC_INSURANCECOST_TICKET]
GO
ALTER TABLE [dbo].[ticket]  WITH CHECK ADD  CONSTRAINT [CKC_TOTALCOST_TICKET] CHECK  (([totalCost] IS NULL OR [totalCost]>=(0)))
GO
ALTER TABLE [dbo].[ticket] CHECK CONSTRAINT [CKC_TOTALCOST_TICKET]
GO
ALTER TABLE [dbo].[ticketType]  WITH CHECK ADD  CONSTRAINT [CKC_MEALSTATUS_TICKETTY] CHECK  (([mealStatus] IS NULL OR ([mealStatus]='无' OR [mealStatus]='有')))
GO
ALTER TABLE [dbo].[ticketType] CHECK CONSTRAINT [CKC_MEALSTATUS_TICKETTY]
GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD  CONSTRAINT [CKC_USERAGE_USERS] CHECK  (([userAge] IS NULL OR [userAge]>=(0) AND [userAge]<=(120)))
GO
ALTER TABLE [dbo].[users] CHECK CONSTRAINT [CKC_USERAGE_USERS]
GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD  CONSTRAINT [CKC_USERSEX_USERS] CHECK  (([userSex] IS NULL OR ([userSex]='女' OR [userSex]='男')))
GO
ALTER TABLE [dbo].[users] CHECK CONSTRAINT [CKC_USERSEX_USERS]
GO
/****** Object:  StoredProcedure [dbo].[reporting]    Script Date: 2020/6/27 19:54:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[reporting] @mon int
as
begin
select f.flightId flightId,sum(case when tp.cabinId=2 then 8 else 120 end) totalTicket,sum(case when tp.cabinId=2 then 8 else 120 end)-sum(tp.remainingTickets) selledTicket,sum(case when cabinId=2 then (8-tp.remainingTickets)*tp.sellingPrice else (120-tp.remainingTickets)*tp.sellingPrice end) income,CAST(CAST((sum(case when DATEDIFF(MINUTE,CONVERT(varchar(100), f.plannedArrivalTime, 24),CONVERT(varchar(100), ef.ATA, 24))<30 then 1 else 0 end)/1.0/COUNT(ef.executiveFlightId)*100) as decimal(10,2)) as varchar(50)) +'%' ontime,COUNT(ef.executiveFlightId)/2 executiveNum from flight f,executiveFlight ef,ticketType tp where f.flightId=ef.flightId and tp.executiveFlightId=ef.executiveFlightId and ef.ATA is not null and month(ef.ATD)=@mon group by f.flightId 
end
GO
/****** Object:  Trigger [dbo].[tr_integral]    Script Date: 2020/6/27 19:54:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create trigger [dbo].[tr_integral] on [dbo].[orders]
for insert 
as
begin
update users set integral=integral-(select offsetIntegral from inserted) where
userId=(select userId from inserted) 
end
GO
ALTER TABLE [dbo].[orders] ENABLE TRIGGER [tr_integral]
GO
/****** Object:  Trigger [dbo].[tr_integral2]    Script Date: 2020/6/27 19:54:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create trigger [dbo].[tr_integral2] on [dbo].[orders]
for delete 
as
begin
update users set integral=integral+(select offsetIntegral from deleted) where
userId=(select userId from deleted) 
end
GO
ALTER TABLE [dbo].[orders] ENABLE TRIGGER [tr_integral2]
GO
/****** Object:  Trigger [dbo].[tr_reserve]    Script Date: 2020/6/27 19:54:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create trigger [dbo].[tr_reserve] on [dbo].[ticket]
for insert 
as
begin
update ticketType set remainingTickets=remainingTickets-1 where
cabinId=(select cabinId from inserted) and executiveFlightID =(select tic_executiveFlightId from inserted)
end
GO
ALTER TABLE [dbo].[ticket] ENABLE TRIGGER [tr_reserve]
GO
/****** Object:  Trigger [dbo].[tr_unsubscribe]    Script Date: 2020/6/27 19:54:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create trigger [dbo].[tr_unsubscribe] on [dbo].[ticket]
for delete 
as
begin
update ticketType set remainingTickets=remainingTickets+1 where
cabinId=(select cabinId from deleted) and executiveFlightID =(select tic_executiveFlightId from deleted)
end
GO
ALTER TABLE [dbo].[ticket] ENABLE TRIGGER [tr_unsubscribe]
GO
USE [master]
GO
ALTER DATABASE [flight] SET  READ_WRITE 
GO
