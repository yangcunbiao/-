//
//  ViewController.swift
//  KeyWordSerch
//
//  Created by Apple on 2020/11/20.
//  Copyright © 2020 first. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var RMBLabel = UILabel(frame: CGRect(x: 60, y: 130, width: 40, height: 20))
    var RMBText=UITextField(frame: CGRect(x: 120, y: 130, width: 100, height: 20))
    var titleLabel=UILabel(frame: CGRect(x: 90, y: 75, width: 80, height: 20))
    var dollarLabel = UILabel(frame: CGRect(x: 60, y: 180, width: 40, height: 20))
    var resultLabel = UILabel(frame: CGRect(x: 120, y: 180, width: 40, height: 20))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

