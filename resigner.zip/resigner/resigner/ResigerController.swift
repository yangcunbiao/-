//
//  ResigerController.swift
//  resigner
//
//  Created by Apple on 2020/11/13.
//  Copyright © 2020 first. All rights reserved.
//

import UIKit

class ResigerController: UIViewController{

    let nameLabel=UILabel(frame: CGRect(x:60,y:90,width:100,height:40))
    let nameTextField=UITextField(frame: CGRect(x:160,y:90,width:150,height:40))
    let passwordLabel=UILabel(frame: CGRect(x:60,y:160,width:100,height:40))
    let passwordText=UITextField(frame: CGRect(x:160,y:160,width:150,height:40))
    let reignerButton=UIButton(frame:CGRect(x:120,y:240,width:80,height:30))
    let backButton=UIButton(frame: CGRect(x: 20, y: 40, width: 40, height: 20))

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor=UIColor.white
        nameLabel.text="用户名"
        self.view.addSubview(nameLabel)
        passwordLabel.text="密码"
        self.view.addSubview(passwordLabel)
        nameTextField.placeholder="请输入用户名"
        nameTextField.borderStyle=UITextField.BorderStyle.roundedRect
        self.view.addSubview(nameTextField)
        passwordText.placeholder="请输入密码"
        passwordText.borderStyle=UITextField.BorderStyle.roundedRect
        self.view.addSubview(passwordText)
        reignerButton.setTitle("注册", for: .normal)
        reignerButton.backgroundColor=UIColor.blue
        reignerButton.addTarget(self, action: #selector(self.dismissSelf), for: .touchUpInside)
        self.view.addSubview(reignerButton)
        backButton.setTitle("返回", for: .normal)
        backButton.backgroundColor=UIColor.black
        backButton.addTarget(self, action: #selector(self.back), for: .touchUpInside)
        self.view.addSubview(backButton)
    }

    @objc func dismissSelf()
    {
        if ViewController.user.keys.contains(nameTextField.text!)
        {
            let alert = UIAlertController(title:"注册失败",message:"用户已存在",preferredStyle:UIAlertController.Style.alert)
            let ok=UIAlertAction(title:"确定",style:UIAlertAction.Style.default,handler:nil)
            alert.addAction(ok)
            self.present(alert,animated: true,completion: nil)
        }
        else{
            ViewController.user[nameTextField.text!]=passwordText.text!
            let alert = UIAlertController(title:"注册成功",message:"请前往登录",preferredStyle:UIAlertController.Style.alert)
            let ok=UIAlertAction(title:"确定",style:UIAlertAction.Style.default,handler:nil)
            alert.addAction(ok)
            self.present(alert,animated: true,completion: nil)
            
        }
    }
    @objc func back()
    {
        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
