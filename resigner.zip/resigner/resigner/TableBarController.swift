//
//  TableBarController.swift
//  resigner
//
//  Created by Apple on 2020/11/27.
//  Copyright © 2020 first. All rights reserved.
//

import UIKit

class TableBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad();
        
    }
}
