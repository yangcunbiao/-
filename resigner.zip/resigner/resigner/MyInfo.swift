//
//  MyInfo.swift
//  resigner
//
//  Created by Apple on 2020/11/27.
//  Copyright © 2020 first. All rights reserved.
//

import UIKit

class MyInfo:UIViewController{
    override func viewDidLoad(){
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
}
