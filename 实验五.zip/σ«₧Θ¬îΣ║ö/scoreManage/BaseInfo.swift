//
//  BaseInfo.swift
//  scoreManage
//
//  Created by Mac on 2020/11/20.
//  Copyright © 2020 robocup. All rights reserved.
//

import UIKit
class BaseInfo {
    var name:String
    var sex:String
    var birdsday:String
    var introduct:String
    init(name:String,sex:String,birdsday:String,introduct:String) {
        self.name=name
        self.sex=sex
        self.birdsday=birdsday
        self.introduct=introduct
    }
}
