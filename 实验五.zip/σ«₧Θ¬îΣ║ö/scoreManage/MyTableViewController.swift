//
//  MyTableViewController.swift
//  scoreManage
//
//  Created by Mac on 2020/11/21.
//  Copyright © 2020 robocup. All rights reserved.
//

import UIKit

class MyTableViewController: UITableViewController {
    var cnt:Int=0
    var scoreInfo:ScoreInfo!
    
    let myView=UIView(frame: CGRect(x:0,y:0,width:400,height: 60))
    let editButton=UIButton(frame: CGRect(x:10,y:15,width:80,height:20))
    let addButton=UIButton(frame: CGRect(x:310,y:15,width:80,height: 20))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cnt=0
        self.title="我的成绩"
        self.view.backgroundColor=UIColor.white
        //self.tabBarItem.image=UIImage(data: "grxx")
        let screenRect=UIScreen.main.bounds
        let tableRect=CGRect(x:0,y:20,width:screenRect.size.width,height:screenRect.size.height)
        let tableView=UITableView(frame:tableRect)
        //tableView.dataSource=self
        
        let statusBarHeight=UIApplication.shared.statusBarFrame.height
        let insets=UIEdgeInsets(top: statusBarHeight, left: 0, bottom: 0, right: 0)
        tableView.contentInset=insets
        tableView.scrollIndicatorInsets=insets
        
        editButton.setTitle("Edit Mode", for: .normal)
        editButton.setTitleColor(UIColor.blue, for: .normal)
        self.view.addSubview(editButton)
        addButton.setTitle("add", for: .normal)
        addButton.setTitleColor(UIColor.blue, for: .normal)
        self.view.addSubview(addButton)
        
        self.view.addSubview(tableView)
        
        myView.backgroundColor=UIColor.blue
        self.tableView.tableHeaderView=myView
        
        scoreInfo=ScoreInfo()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

//    override func numberOfSections(in tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 0
//    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 20
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        let ident="reused"
        var cell=tableView.dequeueReusableCell(withIdentifier: ident)
        
        if(cell==nil)
        {
            cell=UITableViewCell(style:UITableViewCellStyle.value1,reuseIdentifier:ident)
        }
        if cnt<scoreInfo.scoreCollection.count
        {
            cell.textLabel?.text=String(scoreInfo.scoreCollection[cnt].name)
            cell.detailTextLabel?.text=String(scoreInfo.scoreCollection[cnt].score)
            cnt=cnt+1
        }
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
