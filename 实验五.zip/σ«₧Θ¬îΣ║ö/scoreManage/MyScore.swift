//
//  MyScore.swift
//  registry_login
//
//  Created by apple on 2020/11/19.
//  Copyright © 2020年 robocup. All rights reserved.
//

import UIKit
class MyScore:UITableViewController{
    //let cou_sco:Dictionary<String,String>=["c":"85","java":"90"]
    
    var scoreInfo:ScoreInfo!=ScoreInfo()
    var editFlag=true
    
    let myView=UIView(frame: CGRect(x:0,y:0,width:400,height: 40))
    let editButton=UIButton(frame: CGRect(x:10,y:15,width:120,height:20))
    let addButton=UIButton(frame: CGRect(x:230,y:15,width:80,height: 20))
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return 20
        return (scoreInfo?.scoreCollection.count)!
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let ident="reused"
        var cell=tableView.dequeueReusableCell(withIdentifier: ident)
        
        if cell==nil
        {
            cell=UITableViewCell(style:UITableViewCellStyle.value1,reuseIdentifier:ident)
        }
        let score=scoreInfo.scoreCollection[indexPath.row]
        cell?.textLabel?.text=score.name
        cell?.detailTextLabel?.text=String(score.score)
        
        
        
        return cell!
    }
    
    override func tableView(_ tableView:UITableView, editingStyleForRowAt indexPath:IndexPath)->UITableViewCellEditingStyle{
            if editFlag {
                return .delete
                
            }
            else{
                return .insert
            }
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            scoreInfo.scoreCollection.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }else if editingStyle == .insert {
            scoreInfo.scoreCollection.insert(Score(name: "geography", score: 85), at: indexPath.row)
            tableView.insertRows(at: [indexPath], with: .right)
        }
    }
    
    
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        scoreInfo.transferPosition(sourceIndex: sourceIndexPath.row, destinationIndex: destinationIndexPath.row)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title="我的成绩"
        self.view.backgroundColor=UIColor.white
        //self.tabBarItem.image=UIImage(data: "grxx")
        let screenRect=UIScreen.main.bounds
        let tableRect=CGRect(x:0,y:50,width:screenRect.size.width,height:screenRect.size.height)
        let tableView=UITableView(frame:tableRect)
        //tableView.dataSource=self
        
        let statusBarHeight=UIApplication.shared.statusBarFrame.height
        let insets=UIEdgeInsets(top: statusBarHeight, left: 0, bottom: 0, right: 0)
        tableView.contentInset=insets
        tableView.scrollIndicatorInsets=insets
        
        editButton.setTitle("修改", for: .normal)
        editButton.setTitleColor(UIColor.blue, for: .normal)
        editButton.addTarget(self, action: #selector(myEdit(_:)), for: .touchUpInside)
        self.myView.addSubview(editButton)
        addButton.setTitle("增加", for: .normal)
        addButton.setTitleColor(UIColor.blue, for: .normal)
        addButton.addTarget(self, action: #selector(myAdd(_:)), for: .touchUpInside)
        self.myView.addSubview(addButton)
        
        //myView.backgroundColor=UIColor.blue
        self.tableView.tableHeaderView=myView
        
        
        //self.view.addSubview(tableView)
        
        
        
        //scoreInfo=ScoreInfo()
        
    }
    
    @objc func myEdit(_ button:UIButton)
    {
        editFlag = true
        if isEditing {
            setEditing(false, animated: true)
        }else{
            setEditing(true, animated: true)
        }
    }
    
    @objc func myAdd(_ button:UIButton)
    {
        editFlag=false
        if isEditing {
            setEditing(false, animated: true)
        }else{
            setEditing(true, animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
