//
//  ViewController.swift
//  registryAndLogin
//
//  Created by apple on 2020/11/18.
//  Copyright © 2020年 jmu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    static var dic = Dictionary<String,String>()//定义存储用户名和密码的字典
    @IBOutlet var userName: UITextField!   //ctrl拖拽的用户名输入框
    @IBOutlet var password: UITextField!   //ctrl拖拽的密码输入框
    //注册按钮绑定事件
    @IBAction func registry(_ sender: UIButton) {
        sender.addTarget(self, action: #selector(ViewController.openViewController), for: .touchUpInside)
    }
    //登录按钮绑定事件
    @IBAction func login(_ sender: UIButton) {
        if (userName.text?.isEmpty)! || (password.text?.isEmpty)!
        {
            let alert=UIAlertController(title:"登录失败",message:"用户名或密码不能为空",preferredStyle:UIAlertControllerStyle.alert)//定义alter控制器
            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)//定义action
            alert.addAction(ok)//将action加入到alter中
            self.present(alert,animated: true,completion: nil)//将alter控制器添加到页面
        }
        else if ViewController.dic.keys.contains(userName.text!) && ViewController.dic[userName.text!]==password.text!
        {
//            let alert=UIAlertController(title:"登录成功",message:"您已登录成功",preferredStyle:UIAlertControllerStyle.alert)
//            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)
//            alert.addAction(ok)
//            self.present(alert,animated: true,completion: nil)
            let first=MyScore()
            let second=MyBaseInfo()
            let tabbarcon=UITabBarController()
    //        let viewtmp=ViewController()
            //let fixmy=FixMyBaseInfo()
            tabbarcon.viewControllers=[first,second]
            tabbarcon.navigationItem.hidesBackButton=true
            self.navigationController?.pushViewController(tabbarcon, animated: false)
        }
        else
        {
            let alert=UIAlertController(title:"登录失败",message:"用户名不存在或密码错误",preferredStyle:UIAlertControllerStyle.alert)
            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)
            alert.addAction(ok)
            self.present(alert,animated: true,completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //userName.placeholder="请输入用户名"//文本框提示
        //password.placeholder="请输入密码"
        self.view.backgroundColor=UIColor.white
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //模态弹窗
    @objc func openViewController()
    {
        let newViewController = RegistryController()
        self.present(newViewController, animated: true, completion: nil)
        
        func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
    }
}
