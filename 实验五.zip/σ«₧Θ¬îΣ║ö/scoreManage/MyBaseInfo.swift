//
//  MyBaseInfo.swift
//  registry_login
//
//  Created by apple on 2020/11/19.
//  Copyright © 2020年 robocup. All rights reserved.
//

import UIKit
class MyBaseInfo:UIViewController{
    var baseInfo:BaseInfo!
    let nameLable=UILabel(frame: CGRect(x:30,y:80,width:80,height:20))
    let sexLable=UILabel(frame: CGRect(x:30,y:140,width:80,height:20))
    let birdLable=UILabel(frame: CGRect(x:30,y:200,width:80,height:20))
    let nameInfo=UILabel(frame: CGRect(x:230,y:80,width:80,height:20))
    let sexInfo=UILabel(frame: CGRect(x:230,y:140,width:80,height:20))
    let birdInfo=UILabel(frame: CGRect(x:230,y:200,width:80,height:20))
    let introducLable=UILabel(frame: CGRect(x: 30, y: 260, width: 100, height: 20))
    let introducInfo=UITextField(frame: CGRect(x: 130, y: 260, width: 180, height: 120))
    let fixButton=UIButton(frame: CGRect(x: 120, y: 400, width: 60, height: 20))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="我的信息"
        self.view.backgroundColor=UIColor.white
        //self.tabBarItem.image=UIImage(data: "grxx")
        
        baseInfo=AppDelegate.baseInfo
        
        nameLable.text="name"
        self.view.addSubview(nameLable)
        sexLable.text="sex"
        self.view.addSubview(sexLable)
        birdLable.text="birthday"
        self.view.addSubview(birdLable)
        
        nameInfo.text=baseInfo.name
        self.view.addSubview(nameInfo)
        sexInfo.text=baseInfo.sex
        self.view.addSubview(sexInfo)
        birdInfo.text=baseInfo.birdsday
        self.view.addSubview(birdInfo)
        
        introducLable.text="introduct"
        self.view.addSubview(introducLable)
        introducInfo.backgroundColor=UIColor.gray
        introducInfo.text=baseInfo.introduct
        self.view.addSubview(introducInfo)
        
        fixButton.backgroundColor=UIColor.blue
        fixButton.setTitleColor(UIColor.white, for: .normal)
        fixButton.setTitle("Modify", for: .normal)
        fixButton.addTarget(self, action: #selector(openViewController), for: .touchUpInside)
        self.view.addSubview(fixButton)
        //self.view.addSubview(tableView)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func openViewController()//模态弹窗
    {
        let newViewController = FixMyBaseInfo()
        newViewController.preViewController=self
        self.present(newViewController, animated: true, completion: nil)
        
    }
    func update() {
        nameInfo.text=baseInfo.name
        sexInfo.text=baseInfo.sex
        birdInfo.text=baseInfo.birdsday
        introducInfo.text=baseInfo.introduct
    }
}
