//
//  ScoreInfo.swift
//  scoreManage
//
//  Created by Mac on 2020/11/20.
//  Copyright © 2020 robocup. All rights reserved.
//

import UIKit
class ScoreInfo {
    var scoreCollection=[Score]()
    init() {
        let names=["Chinese","Math","English"]
        let scores=[95,100,98]
        for i in 0...(names.count-1)
        {
            let theScore=Score(name: names[i], score: scores[i])
            scoreCollection.append(theScore)
        }
    }
    func transferPosition(sourceIndex:Int,destinationIndex:Int) {
        if sourceIndex != destinationIndex
        {
            let theScore=scoreCollection[sourceIndex]
            scoreCollection.remove(at: sourceIndex)
            scoreCollection.insert(theScore, at: destinationIndex)
        }
    }
    
}

