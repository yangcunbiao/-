//
//  Score.swift
//  scoreManage
//
//  Created by Mac on 2020/11/20.
//  Copyright © 2020 robocup. All rights reserved.
//

import UIKit
class Score: NSObject {
    var name:String
    var score:Int
    init(name:String,score:Int) {
        self.name=name
        self.score=score
        super.init()
    }
}
