//
//  RegistryController.swift
//  registry_login
//
//  Created by robocup on 2020/11/5.
//  Copyright © 2020年 robocup. All rights reserved.
//


import UIKit

class RegistryController: UIViewController {
    
    let unameLable=UILabel(frame: CGRect(x:70,y:300,width:100,height:40))
    let unameText=UITextField(frame: CGRect(x:180,y:300,width:150,height:40))
    let passwdLable=UILabel(frame: CGRect(x:70,y:350,width:100,height:40))
    let passwdText=UITextField(frame: CGRect(x:180,y:350,width:150,height:40))
    let regButton=UIButton(frame:CGRect(x:180,y:430,width:70,height:35))
    let backButton=UIButton(frame:CGRect(x:20,y:30,width:50,height:30))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor=UIColor.white
        unameLable.text="用户名"
        self.view.addSubview(unameLable)
        passwdLable.text="密码"
        self.view.addSubview(passwdLable)
        unameText.placeholder="请输入用户名"
        unameText.borderStyle=UITextBorderStyle.roundedRect
        self.view.addSubview(unameText)
        passwdText.placeholder="请输入密码"
        passwdText.borderStyle=UITextBorderStyle.roundedRect
        self.view.addSubview(passwdText)
        regButton.setTitle("注册", for: .normal)
        regButton.backgroundColor=UIColor.blue
        regButton.addTarget(self, action: #selector(self.dismissSelf), for: .touchUpInside)
        self.view.addSubview(regButton)
        backButton.setTitle("返回", for: .normal)
        backButton.backgroundColor=UIColor.orange
        backButton.addTarget(self, action: #selector(self.back), for: .touchUpInside)
        self.view.addSubview(backButton)
    }
    
    @objc func dismissSelf()//判断是否注册成功
    {
        if LoginController.dic.keys.contains(unameText.text!)//用户已存在注册失败
        {
            let alert = UIAlertController(title:"注册失败",message:"用户已存在",preferredStyle:UIAlertControllerStyle.alert)
            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)
            alert.addAction(ok)
            self.present(alert,animated: true,completion: nil)
        }
        else{
            LoginController.dic[unameText.text!]=passwdText.text!//将用户名和密码添加到字典中
            let alert = UIAlertController(title:"注册成功",message:"请前往登录",preferredStyle:UIAlertControllerStyle.alert)
            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)
            alert.addAction(ok)
            self.present(alert,animated: true,completion: nil)
        }
    }
    @objc func back()//返回登录页面
    {
        self.dismiss(animated: true, completion: nil)//关闭模态弹窗
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
