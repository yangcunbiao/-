//
//  LoginController.swift
//  scoreManage
//
//  Created by robocup on 2020/11/22.
//  Copyright © 2020年 robocup. All rights reserved.
//

import UIKit
class LoginController: UIViewController {
    static var dic = Dictionary<String,String>()//定义存储用户名和密码的字典
    let unameLable=UILabel(frame: CGRect(x:70,y:300,width:100,height:40))
    let unameText=UITextField(frame: CGRect(x:180,y:300,width:150,height:40))
    let passwdLable=UILabel(frame: CGRect(x:70,y:350,width:100,height:40))
    let passwdText=UITextField(frame: CGRect(x:180,y:350,width:150,height:40))
    let regButton=UIButton(frame:CGRect(x:100,y:420,width:80,height:25))
    let loginButton=UIButton(frame:CGRect(x:200,y:420,width:80,height:25))
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor=UIColor.white
        unameLable.text="用户名"
        self.view.addSubview(unameLable)
        passwdLable.text="密码"
        self.view.addSubview(passwdLable)
        unameText.placeholder="请输入用户名"
        unameText.borderStyle=UITextBorderStyle.roundedRect
        self.view.addSubview(unameText)
        passwdText.placeholder="请输入密码"
        passwdText.borderStyle=UITextBorderStyle.roundedRect
        self.view.addSubview(passwdText)
        regButton.setTitle("注册", for: .normal)
        regButton.backgroundColor=UIColor.blue
        regButton.addTarget(self, action: #selector(openViewController), for: .touchUpInside)
        self.view.addSubview(regButton)
        loginButton.setTitle("登录", for: .normal)
        loginButton.backgroundColor=UIColor.blue
        loginButton.addTarget(self, action: #selector(login), for: .touchUpInside)
        self.view.addSubview(loginButton)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func login()
    {
        if (unameText.text?.isEmpty)! || (passwdText.text?.isEmpty)!
        {
            let alert=UIAlertController(title:"登录失败",message:"用户名或密码不能为空",preferredStyle:UIAlertControllerStyle.alert)//定义alter控制器
            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)//定义action
            alert.addAction(ok)//将action加入到alter中
            self.present(alert,animated: true,completion: nil)//将alter控制器添加到页面
        }
        else if LoginController.dic.keys.contains(unameText.text!) && LoginController.dic[unameText.text!]==passwdText.text!
        {

            let first=MyScore()
            let second=MyBaseInfo()
            let tabbarcon=UITabBarController()
            tabbarcon.viewControllers=[first,second]
            tabbarcon.navigationItem.hidesBackButton=true
            self.navigationController?.pushViewController(tabbarcon, animated: false)
        }
        else
        {
            let alert=UIAlertController(title:"登录失败",message:"用户名不存在或密码错误",preferredStyle:UIAlertControllerStyle.alert)
            let ok=UIAlertAction(title:"确定",style:UIAlertActionStyle.default,handler:nil)
            alert.addAction(ok)
            self.present(alert,animated: true,completion: nil)
        }
    }
    

    
    @objc func openViewController()//模态弹窗
    {
        let newViewController = RegistryController()
        self.present(newViewController, animated: true, completion: nil)
    }
}
