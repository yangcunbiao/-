package DiceGame;

public class Die {
    private int num;
    public int roll(){
        return num=(int)(Math.random()*6+1);
    }

    public int getNum() {
        return num;
    }
}
