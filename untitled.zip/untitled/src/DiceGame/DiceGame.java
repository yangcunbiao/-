package DiceGame;

import java.util.Scanner;

public class DiceGame {
    public static void main(String[] argc){
        Scanner in=new Scanner(System.in);
        System.out.println("按回车键开始");
        in.nextLine();
        Die die1=new Die();
        die1.roll();
        System.out.println("第一颗骰子为"+die1.getNum());
        Die die2=new Die();
        die2.roll();
        System.out.println("第二颗骰子为"+die2.getNum());
        if(die1.getNum()+die2.getNum()==7){
            System.out.println("合计为"+(die1.getNum()+die2.getNum())+",你赢了");
        }else{
            System.out.println("合计为"+(die1.getNum()+die2.getNum())+",你输了");
        }
    }

}
